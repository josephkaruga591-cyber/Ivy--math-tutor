import React, { useState, useEffect, useRef } from 'react';
import { GradeLevel, ExplanationStyle, MathSolution } from './types';
import { TopNav } from './components/TopNav';
import { MathInputBar } from './components/MathInputBar';
import { SolutionDisplay } from './components/SolutionDisplay';
import { PracticeLab } from './components/PracticeLab';
import { SampleProblems } from './components/SampleProblems';
import { SavedProblemsModal } from './components/SavedProblemsModal';
import { InteractiveManipulativeLab } from './components/InteractiveManipulativeLab';
import {
  Sparkles,
  HelpCircle,
  AlertCircle,
  Lightbulb,
  CheckCircle2,
  Compass,
  Layers,
} from 'lucide-react';

export default function App() {
  const [selectedGrade, setSelectedGrade] = useState<GradeLevel>('grades_3_4');
  const [currentSolution, setCurrentSolution] = useState<MathSolution | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<'solver' | 'practice' | 'manipulatives'>('solver');
  const [savedSolutions, setSavedSolutions] = useState<MathSolution[]>([]);
  const [isNotebookOpen, setIsNotebookOpen] = useState<boolean>(false);

  const solutionRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLDivElement | null>(null);

  // Load saved problems from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('stepwise_saved_solutions');
      if (stored) {
        setSavedSolutions(JSON.parse(stored));
      }
    } catch {
      // safe fallback
    }
  }, []);

  // Sync saved solutions to localStorage
  const saveSolutionsToStorage = (items: MathSolution[]) => {
    setSavedSolutions(items);
    try {
      localStorage.setItem('stepwise_saved_solutions', JSON.stringify(items));
    } catch {
      // safe fallback
    }
  };

  const handleToggleSaveSolution = (sol: MathSolution) => {
    const exists = savedSolutions.some((s) => s.id === sol.id || s.originalProblem === sol.originalProblem);
    if (exists) {
      const updated = savedSolutions.filter((s) => s.id !== sol.id && s.originalProblem !== sol.originalProblem);
      saveSolutionsToStorage(updated);
    } else {
      const newSol = {
        ...sol,
        id: sol.id || `sol-${Date.now()}`,
        timestamp: Date.now(),
      };
      saveSolutionsToStorage([newSol, ...savedSolutions]);
    }
  };

  const handleDeleteSavedSolution = (id: string) => {
    const updated = savedSolutions.filter((s) => s.id !== id);
    saveSolutionsToStorage(updated);
  };

  // Main Solve Handler
  const handleSolve = async (
    problem: string,
    gradeLevel: GradeLevel,
    style: ExplanationStyle,
    imageBase64?: string
  ) => {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/math/solve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          problem,
          gradeLevel,
          explanationStyle: style,
          imageBase64,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to solve problem.');
      }

      const data: MathSolution = await response.json();
      data.id = `sol-${Date.now()}`;
      data.timestamp = Date.now();
      setCurrentSolution(data);
      setActiveView('solver');

      // Scroll smoothly to solution
      setTimeout(() => {
        solutionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 150);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Something went wrong while solving the problem. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectSample = (problemText: string, grade: GradeLevel) => {
    setSelectedGrade(grade);
    handleSolve(problemText, grade, 'standard');
  };

  const handleNewProblem = () => {
    setActiveView('solver');
    inputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  const isCurrentSaved = Boolean(
    currentSolution &&
      savedSolutions.some(
        (s) => s.id === currentSolution.id || s.originalProblem === currentSolution.originalProblem
      )
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-blue-100 selection:text-blue-900">
      {/* Top Bar (3-Zone Contract) */}
      <TopNav
        activeView={activeView}
        onNavigate={(view) => setActiveView(view)}
        onOpenNotebook={() => setIsNotebookOpen(true)}
        savedCount={savedSolutions.length}
        onNewProblem={handleNewProblem}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
        {/* Hero Banner when no problem is open yet */}
        {!currentSolution && (
          <div className="bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-8 shadow-xs text-center relative overflow-hidden">
            <div className="max-w-2xl mx-auto space-y-3">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-blue-700 bg-blue-50 px-3 py-1 rounded-full mb-1">
                <Compass className="w-3.5 h-3.5" />
                <span>Grades 1–9 Math (Elementary, Middle School & Algebra 1)</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 font-display">
                Understand Every Math Step, Not Just the Answer
              </h1>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                StepWise explains math problems with bite-sized school steps, interactive visual manipulatives (ten-frames, fraction strips, number lines, coordinate planes), and Socratic hints so students build genuine math confidence.
              </p>
            </div>

            {/* Quick feature pill-free highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-6 border-t border-slate-100 text-left">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                  <Lightbulb className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Word Problem Clarity</h4>
                  <p className="text-xs text-slate-500 mt-0.5">Identifies what is asked and highlights key clues and numbers.</p>
                </div>
              </div>

              <button
                onClick={() => setActiveView('manipulatives')}
                className="flex items-start gap-3 text-left hover:bg-slate-50 p-2 rounded-xl transition-colors"
              >
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0 mt-0.5">
                  <Layers className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1">
                    <span>Interactive Manipulatives</span>
                    <span className="text-[10px] text-blue-600 font-semibold underline">Explore</span>
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">Drag & drop addition blocks, fair sharing plates, unit grid geometry, and fraction slices.</p>
                </div>
              </button>

              <button
                onClick={() => {
                  if (currentSolution) {
                    setActiveView('practice');
                  } else {
                    handleSelectSample(
                      'Emma baked 36 cookies and packed 4 in each box. How many boxes did she fill?',
                      selectedGrade
                    );
                  }
                }}
                className="flex items-start gap-3 text-left hover:bg-slate-50 p-2 rounded-xl transition-colors"
              >
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Practice Lab & Checker</h4>
                  <p className="text-xs text-slate-500 mt-0.5">Generates similar practice problems with instant celebratory feedback.</p>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* View 1: Manipulatives Lab */}
        {activeView === 'manipulatives' && (
          <InteractiveManipulativeLab
            onSolveInSolver={(problemText) => {
              handleSolve(problemText, selectedGrade, 'standard');
            }}
          />
        )}

        {/* View 2: Practice Lab */}
        {activeView === 'practice' && currentSolution && (
          <PracticeLab
            topic={currentSolution.topic}
            gradeLevel={currentSolution.gradeLevel}
            originalProblem={currentSolution.originalProblem}
            onBackToSolver={() => setActiveView('solver')}
          />
        )}

        {/* View 3: Standard Solver (MathInputBar + SolutionDisplay + SampleProblems) */}
        {activeView === 'solver' && (
          <>
            {/* Math Input Section */}
            <div ref={inputRef}>
              <MathInputBar
                onSolve={handleSolve}
                isLoading={isLoading}
                selectedGrade={selectedGrade}
                onGradeChange={(grade) => setSelectedGrade(grade)}
              />
            </div>

            {/* Error message alert */}
            {errorMessage && (
              <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs sm:text-sm text-rose-800 flex items-start gap-3">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <strong>Error:</strong> {errorMessage}
                </div>
              </div>
            )}

            {/* Current Solution */}
            {currentSolution && (
              <div ref={solutionRef}>
                <SolutionDisplay
                  solution={currentSolution}
                  onOpenPractice={() => setActiveView('practice')}
                  onSaveSolution={handleToggleSaveSolution}
                  isSaved={isCurrentSaved}
                />
              </div>
            )}

            {/* Sample Problems Library */}
            <SampleProblems
              gradeLevel={selectedGrade}
              onSelectProblem={handleSelectSample}
            />
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto py-6 border-t border-slate-200 bg-white text-xs text-slate-500">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">StepWise Math Tutor (Grades 1–9)</span>
            <span aria-hidden="true">·</span>
            <span>Empowering students to understand math step-by-step from elementary through Algebra 1</span>
          </div>
          <div>Built for students, parents, and teachers</div>
        </div>
      </footer>

      {/* Saved Homework Notebook Modal */}
      <SavedProblemsModal
        isOpen={isNotebookOpen}
        onClose={() => setIsNotebookOpen(false)}
        savedSolutions={savedSolutions}
        onSelectSolution={(sol) => {
          setCurrentSolution(sol);
          setSelectedGrade(sol.gradeLevel);
          setActiveView('solver');
        }}
        onDeleteSolution={handleDeleteSavedSolution}
      />
    </div>
  );
}
