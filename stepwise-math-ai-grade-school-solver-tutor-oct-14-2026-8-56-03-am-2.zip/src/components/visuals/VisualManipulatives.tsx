import React, { useState } from 'react';
import { VisualModel } from '../../types';
import {
  Layers,
  Sparkles,
  RotateCcw,
  Plus,
  Minus,
  CheckCircle2,
  Grid,
  MoveHorizontal,
  HelpCircle,
  Shapes,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface VisualManipulativesProps {
  model: VisualModel;
  topic?: string;
  onSolveTarget?: () => void;
}

export const VisualManipulatives: React.FC<VisualManipulativesProps> = ({ model, topic }) => {
  const { type, params } = model;

  return (
    <div className="bg-white border border-slate-200/90 rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
      {/* Visual Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
            {type === 'geometric_shapes' ? (
              <Shapes className="w-4 h-4" />
            ) : (
              <Layers className="w-4 h-4" />
            )}
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900">Interactive Visual Manipulative</h4>
            <span className="text-xs text-slate-500">
              Directly manipulate objects, sliders, and counters to see how the math works
            </span>
          </div>
        </div>

        <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg self-start sm:self-auto">
          {topic || 'Hands-On Math Tool'}
        </span>
      </div>

      {/* Render Appropriate Interactive Manipulative */}
      <div className="py-1">
        {type === 'drag_drop_blocks' && (
          <DragDropBlocksView
            initialA={params.groupA ?? 7}
            initialB={params.groupB ?? 5}
            targetSum={params.targetSum ?? ((params.groupA ?? 7) + (params.groupB ?? 5))}
            itemType={params.itemType || 'blocks'}
            operation={params.operation || 'add'}
          />
        )}

        {type === 'drag_drop_division' && (
          <DragDropDivisionView
            totalItems={params.totalItems ?? 12}
            groupCount={params.groupCount ?? 3}
            itemLabel={params.itemLabel || 'cookies'}
          />
        )}

        {type === 'geometric_shapes' && (
          <GeometricShapesView
            initialShape={params.shape || 'rectangle'}
            initialWidth={params.width || 6}
            initialHeight={params.height || 4}
            initialBase={params.base || 8}
            initialRadius={params.radius || 5}
            unit={params.unit || 'cm'}
            defaultShowGrid={params.showGrid ?? true}
          />
        )}

        {type === 'fraction_bars' && (
          <InteractiveFractionBarsView
            initialFractions={params.fractions || [
              { numerator: 3, denominator: 4, label: 'Fraction 1' },
              { numerator: 1, denominator: 2, label: 'Fraction 2' },
            ]}
          />
        )}

        {type === 'number_line' && (
          <InteractiveNumberLineView
            start={params.start ?? 0}
            end={params.end ?? 20}
            jumps={params.jumps || []}
            initialMarker={params.initialMarker}
            targetMarker={params.targetMarker}
          />
        )}

        {type === 'ten_frame' && <TenFrameView frames={params.frames || []} />}

        {type === 'multiplication_array' && (
          <MultiplicationArrayView
            rows={params.rows || 4}
            cols={params.cols || 6}
            total={params.total || (params.rows || 4) * (params.cols || 6)}
            rowLabel={params.rowLabel || `${params.rows || 4} rows`}
            colLabel={params.colLabel || `${params.cols || 6} columns`}
          />
        )}

        {type === 'balance_scale' && (
          <BalanceScaleView
            leftSide={params.leftSide || '2x + 4'}
            rightSide={params.rightSide || '12'}
            variable={params.variable || 'x'}
            value={params.value || 4}
          />
        )}

        {type === 'bar_comparison' && <BarComparisonView bars={params.bars || []} />}
        {type === 'pie_chart' && <PieChartView slices={params.slices || []} />}

        {type === 'coordinate_graph' && (
          <CoordinateGraphView
            initialSlope={params.slope ?? 2}
            initialIntercept={params.intercept ?? -1}
            lineEquation={params.lineEquation}
            points={params.points}
          />
        )}

        {![
          'coordinate_graph',
          'drag_drop_blocks',
          'drag_drop_division',
          'geometric_shapes',
          'fraction_bars',
          'number_line',
          'ten_frame',
          'multiplication_array',
          'balance_scale',
          'bar_comparison',
          'pie_chart',
        ].includes(type) && <DefaultVisualFallback model={model} />}
      </div>
    </div>
  );
};

// =========================================================================
// 1. DRAG & DROP BLOCKS / COUNTERS (Addition, Subtraction, Regrouping)
// =========================================================================
export const DragDropBlocksView: React.FC<{
  initialA: number;
  initialB: number;
  targetSum: number;
  itemType?: string;
  operation?: string;
}> = ({ initialA, initialB, targetSum, itemType = 'blocks' }) => {
  const [basketA, setBasketA] = useState<number>(initialA);
  const [basketB, setBasketB] = useState<number>(initialB);
  const [draggedFrom, setDraggedFrom] = useState<'A' | 'B' | null>(null);

  const currentTotal = basketA + basketB;
  const isTargetMatched = currentTotal === targetSum;

  const handleDragStart = (from: 'A' | 'B') => {
    setDraggedFrom(from);
  };

  const handleDrop = (to: 'A' | 'B') => {
    if (!draggedFrom || draggedFrom === to) return;

    if (draggedFrom === 'A' && basketA > 0) {
      setBasketA((prev) => prev - 1);
      setBasketB((prev) => prev + 1);
    } else if (draggedFrom === 'B' && basketB > 0) {
      setBasketB((prev) => prev - 1);
      setBasketA((prev) => prev + 1);
    }
    setDraggedFrom(null);
  };

  const handleTransfer = (from: 'A' | 'B', to: 'A' | 'B') => {
    if (from === 'A' && basketA > 0) {
      setBasketA((prev) => prev - 1);
      setBasketB((prev) => prev + 1);
    } else if (from === 'B' && basketB > 0) {
      setBasketB((prev) => prev - 1);
      setBasketA((prev) => prev + 1);
    }
  };

  const handleReset = () => {
    setBasketA(initialA);
    setBasketB(initialB);
  };

  return (
    <div className="space-y-4">
      {/* Instructional Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1.5 font-medium">
          <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
          <span>
            Click or drag {itemType} between Group A and Group B to see how the numbers combine into the total!
          </span>
        </div>
        <button
          onClick={handleReset}
          className="flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-slate-900 self-start sm:self-auto"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      {/* Dynamic Live Equation Tally */}
      <div className="flex items-center justify-center gap-3 p-4 bg-blue-50/60 border border-blue-200 rounded-xl font-display text-center">
        <div className="text-blue-900 font-bold text-lg sm:text-2xl">
          {basketA} <span className="text-xs font-normal text-blue-700 block">Group A</span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-blue-600">+</div>
        <div className="text-amber-900 font-bold text-lg sm:text-2xl">
          {basketB} <span className="text-xs font-normal text-amber-700 block">Group B</span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-slate-600">=</div>
        <div className="text-emerald-900 font-bold text-lg sm:text-2xl">
          {currentTotal} <span className="text-xs font-normal text-emerald-700 block">Total Combined</span>
        </div>
      </div>

      {/* Interactive Drop Mats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Basket A */}
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={() => handleDrop('A')}
          className="bg-blue-50/40 border-2 border-dashed border-blue-300 hover:border-blue-500 rounded-2xl p-4 transition-colors relative"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-blue-900">Group A ({basketA} {itemType})</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setBasketA((p) => Math.max(0, p - 1))}
                className="w-5 h-5 rounded bg-white border border-slate-200 text-slate-600 flex items-center justify-center hover:bg-slate-100"
                title="Remove 1 block"
              >
                <Minus className="w-3 h-3" />
              </button>
              <button
                onClick={() => setBasketA((p) => p + 1)}
                className="w-5 h-5 rounded bg-white border border-slate-200 text-slate-600 flex items-center justify-center hover:bg-slate-100"
                title="Add 1 block"
              >
                <Plus className="w-3 h-3" />
              </button>
              <button
                onClick={() => handleTransfer('A', 'B')}
                disabled={basketA <= 0}
                className="ml-1 text-[11px] font-semibold text-blue-700 hover:text-blue-900 disabled:opacity-30 bg-blue-100/70 px-2 py-0.5 rounded"
              >
                Move to B ➔
              </button>
            </div>
          </div>

          {/* Blocks container */}
          <div className="flex flex-wrap gap-2 min-h-[90px] p-2 bg-white/80 rounded-xl border border-blue-100 items-center content-start">
            {basketA === 0 ? (
              <span className="text-xs text-slate-400 italic mx-auto self-center">Mat is empty</span>
            ) : (
              Array.from({ length: basketA }).map((_, i) => (
                <div
                  key={i}
                  draggable
                  onDragStart={() => handleDragStart('A')}
                  onClick={() => handleTransfer('A', 'B')}
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px] flex items-center justify-center cursor-grab active:cursor-grabbing shadow-xs transition-transform hover:scale-105 select-none"
                  title="Click or drag to move to Group B"
                >
                  {i + 1}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Basket B */}
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={() => handleDrop('B')}
          className="bg-amber-50/40 border-2 border-dashed border-amber-300 hover:border-amber-500 rounded-2xl p-4 transition-colors relative"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-amber-900">Group B ({basketB} {itemType})</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setBasketB((p) => Math.max(0, p - 1))}
                className="w-5 h-5 rounded bg-white border border-slate-200 text-slate-600 flex items-center justify-center hover:bg-slate-100"
                title="Remove 1 block"
              >
                <Minus className="w-3 h-3" />
              </button>
              <button
                onClick={() => setBasketB((p) => p + 1)}
                className="w-5 h-5 rounded bg-white border border-slate-200 text-slate-600 flex items-center justify-center hover:bg-slate-100"
                title="Add 1 block"
              >
                <Plus className="w-3 h-3" />
              </button>
              <button
                onClick={() => handleTransfer('B', 'A')}
                disabled={basketB <= 0}
                className="ml-1 text-[11px] font-semibold text-amber-800 hover:text-amber-900 disabled:opacity-30 bg-amber-100/70 px-2 py-0.5 rounded"
              >
                Move to A ➔
              </button>
            </div>
          </div>

          {/* Blocks container */}
          <div className="flex flex-wrap gap-2 min-h-[90px] p-2 bg-white/80 rounded-xl border border-amber-100 items-center content-start">
            {basketB === 0 ? (
              <span className="text-xs text-slate-400 italic mx-auto self-center">Mat is empty</span>
            ) : (
              Array.from({ length: basketB }).map((_, i) => (
                <div
                  key={i}
                  draggable
                  onDragStart={() => handleDragStart('B')}
                  onClick={() => handleTransfer('B', 'A')}
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-[11px] flex items-center justify-center cursor-grab active:cursor-grabbing shadow-xs transition-transform hover:scale-105 select-none"
                  title="Click or drag to move to Group A"
                >
                  {i + 1}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Target celebration indicator */}
      {isTargetMatched && (
        <div className="flex items-center justify-center gap-2 p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs font-semibold">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>
            Target reached! Group A ({basketA}) and Group B ({basketB}) together equal {targetSum} {itemType}.
          </span>
        </div>
      )}
    </div>
  );
};

// =========================================================================
// 2. DRAG & DROP DIVISION & FAIR SHARING (Equal Groups & Remainders)
// =========================================================================
export const DragDropDivisionView: React.FC<{
  totalItems: number;
  groupCount: number;
  itemLabel?: string;
}> = ({ totalItems, groupCount, itemLabel = 'cookies' }) => {
  const [baskets, setBaskets] = useState<number[]>(Array(groupCount).fill(0));
  const [unassigned, setUnassigned] = useState<number>(totalItems);

  // Distribute one item into a specific basket
  const assignToBasket = (basketIdx: number) => {
    if (unassigned <= 0) return;
    setUnassigned((prev) => prev - 1);
    setBaskets((prev) => {
      const next = [...prev];
      next[basketIdx] += 1;
      return next;
    });
  };

  // Remove one item from a basket back to supply
  const removeFromBasket = (basketIdx: number) => {
    if (baskets[basketIdx] <= 0) return;
    setUnassigned((prev) => prev + 1);
    setBaskets((prev) => {
      const next = [...prev];
      next[basketIdx] -= 1;
      return next;
    });
  };

  // Fair distribute 1 to each basket
  const distributeRoundRobin = () => {
    if (unassigned < groupCount) return;
    setUnassigned((prev) => prev - groupCount);
    setBaskets((prev) => prev.map((count) => count + 1));
  };

  // Reset to original supply
  const handleReset = () => {
    setBaskets(Array(groupCount).fill(0));
    setUnassigned(totalItems);
  };

  // Calculate if fair sharing is achieved
  const itemsInFirst = baskets[0];
  const allEqual = baskets.every((c) => c === itemsInFirst && c > 0);
  const isComplete = allEqual && unassigned < groupCount;

  return (
    <div className="space-y-4">
      {/* Instruction & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1.5 font-medium">
          <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
          <span>
            Share {totalItems} {itemLabel} equally into {groupCount} plates. Click any plate to drop an item, or use "Share 1 Each"!
          </span>
        </div>
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={distributeRoundRobin}
            disabled={unassigned < groupCount}
            className="px-2.5 py-1 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 rounded-md transition-colors"
          >
            Share 1 Each
          </button>
          <button
            onClick={handleReset}
            className="flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-slate-900"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Unassigned Supply Bin */}
      <div className="p-3 bg-white border border-slate-200 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-800">
            Supply Bin ({unassigned} {itemLabel} remaining to share):
          </span>
        </div>
        <div className="flex flex-wrap gap-1.5 justify-center">
          {Array.from({ length: unassigned }).map((_, i) => (
            <button
              key={i}
              onClick={() => {
                // Auto drop into basket with lowest items
                const minCount = Math.min(...baskets);
                const targetIdx = baskets.indexOf(minCount);
                assignToBasket(targetIdx);
              }}
              className="w-6 h-6 rounded-full bg-amber-400 hover:bg-amber-500 border border-amber-600/40 text-amber-950 font-bold text-[10px] flex items-center justify-center shadow-xs cursor-pointer active:scale-90 transition-transform"
              title="Click to drop into next plate"
            >
              🍪
            </button>
          ))}
          {unassigned === 0 && (
            <span className="text-xs font-semibold text-emerald-700">All {itemLabel} distributed!</span>
          )}
        </div>
      </div>

      {/* Plates / Baskets Container */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {baskets.map((count, idx) => (
          <div
            key={idx}
            onClick={() => assignToBasket(idx)}
            className="bg-slate-50 hover:bg-blue-50/30 border-2 border-slate-300 hover:border-blue-400 rounded-2xl p-4 transition-all cursor-pointer relative"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800">Plate #{idx + 1}</span>
              <div className="flex items-center gap-1">
                <span className="text-xs font-mono font-bold text-blue-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                  {count} items
                </span>
                {count > 0 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeFromBasket(idx);
                    }}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded"
                    title="Remove 1 item"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* Items inside plate */}
            <div className="min-h-[70px] bg-white rounded-xl p-2 border border-slate-200 flex flex-wrap gap-1.5 items-center justify-center content-center">
              {count === 0 ? (
                <span className="text-[11px] text-slate-400 italic">Empty plate (tap to add)</span>
              ) : (
                Array.from({ length: count }).map((_, itemI) => (
                  <span
                    key={itemI}
                    className="w-6 h-6 rounded-full bg-amber-100 border border-amber-400 text-amber-900 font-bold text-[10px] flex items-center justify-center shadow-xs select-none"
                  >
                    🍪
                  </span>
                ))
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Fair Share Completion Banner */}
      {isComplete && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-950 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <h5 className="text-xs sm:text-sm font-bold">Fair Sharing Complete!</h5>
              <p className="text-xs text-emerald-800">
                {totalItems} ÷ {groupCount} = <strong>{itemsInFirst} each</strong>
                {unassigned > 0 ? ` (with ${unassigned} remainder)` : ' with 0 left over!'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              confetti({ particleCount: 40, spread: 60, origin: { y: 0.7 } });
            }}
            className="px-3 py-1.5 text-xs font-semibold text-emerald-950 bg-white border border-emerald-300 rounded-lg hover:bg-emerald-100 transition-colors"
          >
            Celebrate 🎉
          </button>
        </div>
      )}
    </div>
  );
};

// =========================================================================
// 3. GEOMETRIC SHAPES & UNIT GRID EXPLORER (Area, Perimeter, Dimensions)
// =========================================================================
export const GeometricShapesView: React.FC<{
  initialShape?: string;
  initialWidth?: number;
  initialHeight?: number;
  initialBase?: number;
  initialRadius?: number;
  unit?: string;
  defaultShowGrid?: boolean;
}> = ({
  initialShape = 'rectangle',
  initialWidth = 6,
  initialHeight = 4,
  initialBase = 8,
  initialRadius = 5,
  unit = 'cm',
  defaultShowGrid = true,
}) => {
  const [shape, setShape] = useState<string>(initialShape);
  const [width, setWidth] = useState<number>(initialWidth);
  const [height, setHeight] = useState<number>(initialHeight);
  const [base, setBase] = useState<number>(initialBase);
  const [radius, setRadius] = useState<number>(initialRadius);
  const [showGrid, setShowGrid] = useState<boolean>(defaultShowGrid);

  // Calculations
  const rectArea = width * height;
  const rectPerimeter = 2 * (width + height);

  const triArea = 0.5 * base * height;
  const triPerimeter = base + 2 * Math.sqrt(Math.pow(base / 2, 2) + Math.pow(height, 2));

  const circleArea = (Math.PI * radius * radius).toFixed(1);
  const circleCircumference = (2 * Math.PI * radius).toFixed(1);

  return (
    <div className="space-y-4">
      {/* Shape Selector & Grid Toggle */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-slate-100">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
          {[
            { id: 'rectangle', label: 'Rectangle' },
            { id: 'triangle', label: 'Triangle' },
            { id: 'circle', label: 'Circle' },
          ].map((s) => (
            <button
              key={s.id}
              onClick={() => setShape(s.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                shape === s.id
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        <button
          onClick={() => setShowGrid(!showGrid)}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border transition-colors ${
            showGrid
              ? 'bg-blue-50 text-blue-700 border-blue-200'
              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Grid className="w-3.5 h-3.5" />
          <span>{showGrid ? 'Unit Square Grid: ON' : 'Show Unit Grid'}</span>
        </button>
      </div>

      {/* Main Sandbox Area */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-stretch">
        {/* Visual Drawing Stage (2 cols on md) */}
        <div className="md:col-span-2 bg-slate-50 border border-slate-200 rounded-2xl p-6 flex flex-col items-center justify-center min-h-[260px] relative overflow-hidden">
          {/* Rectangle View */}
          {shape === 'rectangle' && (
            <div className="flex flex-col items-center gap-2">
              <span className="text-xs font-bold text-slate-700 font-mono">
                Width = {width} {unit}
              </span>
              <div className="flex items-center gap-3">
                <span className="text-xs font-bold text-slate-700 font-mono -rotate-90 origin-center whitespace-nowrap">
                  Height = {height} {unit}
                </span>

                {/* The Rectangle */}
                <div
                  className="border-2 border-blue-600 bg-blue-100/70 rounded-lg transition-all relative overflow-hidden flex items-center justify-center shadow-xs"
                  style={{
                    width: `${Math.min(320, width * 32)}px`,
                    height: `${Math.min(200, height * 32)}px`,
                  }}
                >
                  {/* Unit Square Grid Overlay */}
                  {showGrid && (
                    <div
                      className="absolute inset-0 grid divide-x divide-y divide-blue-300/80 pointer-events-none"
                      style={{
                        gridTemplateColumns: `repeat(${width}, 1fr)`,
                        gridTemplateRows: `repeat(${height}, 1fr)`,
                      }}
                    >
                      {Array.from({ length: width * height }).map((_, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-center text-[9px] font-bold text-blue-800/60 font-mono"
                        >
                          {i + 1}
                        </div>
                      ))}
                    </div>
                  )}
                  {!showGrid && (
                    <span className="text-xs font-bold text-blue-900 font-display">
                      {rectArea} {unit}²
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Triangle View */}
          {shape === 'triangle' && (
            <div className="flex flex-col items-center gap-2">
              <div className="relative">
                <svg
                  width={Math.min(320, base * 32)}
                  height={Math.min(200, height * 32)}
                  viewBox={`0 0 ${base * 10} ${height * 10}`}
                  className="overflow-visible"
                >
                  <polygon
                    points={`${(base * 10) / 2},0 0,${height * 10} ${base * 10},${height * 10}`}
                    fill="rgba(59, 130, 246, 0.25)"
                    stroke="#2563eb"
                    strokeWidth="3"
                  />
                  {/* Altitude / Height line */}
                  <line
                    x1={(base * 10) / 2}
                    y1={0}
                    x2={(base * 10) / 2}
                    y2={height * 10}
                    stroke="#d97706"
                    strokeWidth="2"
                    strokeDasharray="4 3"
                  />
                </svg>
              </div>
              <div className="flex items-center gap-4 text-xs font-mono font-bold text-slate-700 mt-2">
                <span>Base = {base} {unit}</span>
                <span className="text-amber-700">Height = {height} {unit}</span>
              </div>
            </div>
          )}

          {/* Circle View */}
          {shape === 'circle' && (
            <div className="flex flex-col items-center gap-2">
              <div
                className="rounded-full border-2 border-emerald-500 bg-emerald-100/60 transition-all flex items-center justify-center relative shadow-xs"
                style={{
                  width: `${Math.min(220, radius * 30)}px`,
                  height: `${Math.min(220, radius * 30)}px`,
                }}
              >
                {/* Radius line */}
                <div className="absolute left-1/2 top-1/2 w-1/2 h-0.5 bg-emerald-700 origin-left flex items-center">
                  <span className="absolute -top-4 left-1/2 -translate-x-1/2 text-[10px] font-mono font-bold text-emerald-900 bg-white px-1 rounded">
                    r = {radius} {unit}
                  </span>
                </div>
                <div className="w-2 h-2 rounded-full bg-emerald-800" />
              </div>
            </div>
          )}
        </div>

        {/* Dimension Sliders & Live Formulas (1 col) */}
        <div className="space-y-4 flex flex-col justify-between">
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-4">
            <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Adjust Dimensions
            </h5>

            {shape === 'rectangle' && (
              <>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-medium text-slate-700">
                    <span>Width ({unit}):</span>
                    <strong className="font-mono text-blue-700">{width}</strong>
                  </div>
                  <input
                    type="range"
                    min={1}
                    max={10}
                    value={width}
                    onChange={(e) => setWidth(Number(e.target.value))}
                    className="w-full accent-blue-600"
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-medium text-slate-700">
                    <span>Height ({unit}):</span>
                    <strong className="font-mono text-blue-700">{height}</strong>
                  </div>
                  <input
                    type="range"
                    min={1}
                    max={8}
                    value={height}
                    onChange={(e) => setHeight(Number(e.target.value))}
                    className="w-full accent-blue-600"
                  />
                </div>
              </>
            )}

            {shape === 'triangle' && (
              <>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-medium text-slate-700">
                    <span>Base ({unit}):</span>
                    <strong className="font-mono text-blue-700">{base}</strong>
                  </div>
                  <input
                    type="range"
                    min={2}
                    max={12}
                    value={base}
                    onChange={(e) => setBase(Number(e.target.value))}
                    className="w-full accent-blue-600"
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-medium text-slate-700">
                    <span>Height ({unit}):</span>
                    <strong className="font-mono text-amber-700">{height}</strong>
                  </div>
                  <input
                    type="range"
                    min={2}
                    max={8}
                    value={height}
                    onChange={(e) => setHeight(Number(e.target.value))}
                    className="w-full accent-amber-600"
                  />
                </div>
              </>
            )}

            {shape === 'circle' && (
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-medium text-slate-700">
                  <span>Radius ({unit}):</span>
                  <strong className="font-mono text-emerald-700">{radius}</strong>
                </div>
                <input
                  type="range"
                  min={1}
                  max={8}
                  value={radius}
                  onChange={(e) => setRadius(Number(e.target.value))}
                  className="w-full accent-emerald-600"
                />
              </div>
            )}
          </div>

          {/* Formulas Output Card */}
          <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-4 space-y-2 text-xs">
            <div className="font-bold text-blue-950 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Calculated Measurements</span>
            </div>

            {shape === 'rectangle' && (
              <div className="space-y-1 text-slate-800">
                <div>
                  <strong>Area Formula:</strong> <span className="font-mono">width × height</span>
                </div>
                <div className="text-blue-900 font-bold font-mono">
                  {width} × {height} = {rectArea} {unit}²
                </div>
                <div className="pt-1">
                  <strong>Perimeter:</strong> <span className="font-mono">2({width}) + 2({height}) = {rectPerimeter} {unit}</span>
                </div>
              </div>
            )}

            {shape === 'triangle' && (
              <div className="space-y-1 text-slate-800">
                <div>
                  <strong>Area Formula:</strong> <span className="font-mono">½ × base × height</span>
                </div>
                <div className="text-blue-900 font-bold font-mono">
                  ½ × {base} × {height} = {triArea} {unit}²
                </div>
                <div className="pt-1">
                  <strong>Estimated Perimeter:</strong> <span className="font-mono">{triPerimeter.toFixed(1)} {unit}</span>
                </div>
              </div>
            )}

            {shape === 'circle' && (
              <div className="space-y-1 text-slate-800">
                <div>
                  <strong>Area Formula:</strong> <span className="font-mono">π × r²</span>
                </div>
                <div className="text-emerald-900 font-bold font-mono">
                  3.1415 × {radius}² = {circleArea} {unit}²
                </div>
                <div className="pt-1">
                  <strong>Circumference:</strong> <span className="font-mono">2 × π × {radius} = {circleCircumference} {unit}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 4. INTERACTIVE FRACTION BARS & EQUIVALENCE SLICER
// =========================================================================
export const InteractiveFractionBarsView: React.FC<{
  initialFractions: Array<{ numerator: number; denominator: number; label: string; color?: string }>;
}> = ({ initialFractions }) => {
  const [fractions, setFractions] = useState(initialFractions);

  const updateSlice = (idx: number, pieceIdx: number) => {
    setFractions((prev) =>
      prev.map((f, i) => {
        if (i !== idx) return f;
        const newNum = pieceIdx < f.numerator ? pieceIdx : pieceIdx + 1;
        return { ...f, numerator: newNum };
      })
    );
  };

  const changeDenominator = (idx: number, delta: number) => {
    setFractions((prev) =>
      prev.map((f, i) => {
        if (i !== idx) return f;
        const newDen = Math.max(1, Math.min(12, f.denominator + delta));
        const newNum = Math.min(f.numerator, newDen);
        return { ...f, denominator: newDen, numerator: newNum };
      })
    );
  };

  const colors = [
    { fill: 'bg-indigo-600', hover: 'hover:bg-indigo-500', light: 'bg-indigo-50', text: 'text-indigo-900' },
    { fill: 'bg-emerald-600', hover: 'hover:bg-emerald-500', light: 'bg-emerald-50', text: 'text-emerald-900' },
    { fill: 'bg-amber-600', hover: 'hover:bg-amber-500', light: 'bg-amber-50', text: 'text-amber-900' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1.5 font-medium">
          <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
          <span>
            Click parts to shade/unshade, or use +/- to slice into more pieces to find equivalent fractions!
          </span>
        </div>
      </div>

      <div className="space-y-4">
        {fractions.map((frac, idx) => {
          const num = Math.max(0, frac.numerator);
          const den = Math.max(1, frac.denominator);
          const percent = Math.min(100, Math.round((num / den) * 100));
          const color = colors[idx % colors.length];

          return (
            <div key={idx} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-800">{frac.label || `Fraction ${idx + 1}`}</span>
                  <span className="text-xs font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-300">
                    {num} / {den}
                  </span>
                  <span className="text-xs text-slate-500 font-mono">({percent}%)</span>
                </div>

                {/* Slices Controls */}
                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                  <span>Slices ({den}):</span>
                  <button
                    onClick={() => changeDenominator(idx, -1)}
                    disabled={den <= 1}
                    className="w-5 h-5 rounded bg-white border border-slate-200 flex items-center justify-center hover:bg-slate-100 disabled:opacity-30"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => changeDenominator(idx, 1)}
                    disabled={den >= 12}
                    className="w-5 h-5 rounded bg-white border border-slate-200 flex items-center justify-center hover:bg-slate-100 disabled:opacity-30"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Interactive Slices Bar */}
              <div className="h-10 w-full bg-white border-2 border-slate-300 rounded-xl overflow-hidden flex divide-x divide-slate-200 shadow-2xs">
                {Array.from({ length: den }).map((_, pieceIdx) => {
                  const isFilled = pieceIdx < num;
                  return (
                    <button
                      key={pieceIdx}
                      onClick={() => updateSlice(idx, pieceIdx)}
                      style={{ flex: 1 }}
                      className={`h-full flex items-center justify-center text-[10px] font-bold transition-all cursor-pointer ${
                        isFilled
                          ? `${color.fill} ${color.hover} text-white`
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-400'
                      }`}
                      title={`Part ${pieceIdx + 1} of ${den} (Click to toggle)`}
                    >
                      1/{den}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// =========================================================================
// 5. INTERACTIVE NUMBER LINE WITH DRAGGABLE MARKER & HOPS
// =========================================================================
export const InteractiveNumberLineView: React.FC<{
  start: number;
  end: number;
  jumps: Array<{ from: number; to: number; label: string }>;
  initialMarker?: number;
  targetMarker?: number;
}> = ({ start, end, jumps, initialMarker }) => {
  const safeStart = Number.isFinite(start) ? start : 0;
  const safeEnd = Number.isFinite(end) && end > safeStart ? end : safeStart + 20;
  const range = safeEnd - safeStart || 1;

  const [currentVal, setCurrentVal] = useState<number>(
    initialMarker !== undefined ? initialMarker : safeStart + Math.round(range / 2)
  );

  const getPercent = (val: number) => {
    return Math.max(0, Math.min(100, ((val - safeStart) / range) * 100));
  };

  const step = Math.max(1, Math.round(range / 10));
  const ticks: number[] = [];
  for (let t = safeStart; t <= safeEnd; t += step) {
    ticks.push(t);
  }
  if (!ticks.includes(safeEnd)) ticks.push(safeEnd);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1.5 font-medium">
          <MoveHorizontal className="w-3.5 h-3.5 text-blue-600" />
          <span>
            Slide or hop the frog marker along the line to count forward (+) or backward (-)!
          </span>
        </div>
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setCurrentVal((p) => Math.max(safeStart, p - 1))}
            className="px-2 py-1 bg-white border border-slate-200 hover:bg-slate-100 rounded text-xs font-semibold"
          >
            -1 Hop
          </button>
          <button
            onClick={() => setCurrentVal((p) => Math.min(safeEnd, p + 1))}
            className="px-2 py-1 bg-white border border-slate-200 hover:bg-slate-100 rounded text-xs font-semibold"
          >
            +1 Hop
          </button>
        </div>
      </div>

      {/* Number Line Canvas */}
      <div className="relative pt-12 pb-8 px-6 bg-slate-50 border border-slate-200 rounded-xl overflow-hidden">
        {/* Static Jump Arcs */}
        {jumps.map((jump, idx) => {
          const leftPct = getPercent(Math.min(jump.from, jump.to));
          const rightPct = getPercent(Math.max(jump.from, jump.to));
          const widthPct = Math.max(3, rightPct - leftPct);
          const isForward = jump.to >= jump.from;

          return (
            <div
              key={idx}
              className="absolute pointer-events-none"
              style={{
                left: `${leftPct}%`,
                width: `${widthPct}%`,
                top: `${8 + (idx % 2) * 16}px`,
                height: '36px',
              }}
            >
              <svg className="w-full h-full overflow-visible" viewBox="0 0 100 40" preserveAspectRatio="none">
                <path
                  d="M 2 38 Q 50 2 98 38"
                  fill="none"
                  stroke={isForward ? '#2563eb' : '#dc2626'}
                  strokeWidth="2.5"
                  strokeDasharray="4 2"
                />
              </svg>
              <div
                className={`absolute -top-3 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded text-[11px] font-bold ${
                  isForward ? 'bg-blue-600 text-white' : 'bg-red-600 text-white'
                } shadow-xs whitespace-nowrap`}
              >
                {jump.label || (isForward ? `+${jump.to - jump.from}` : `${jump.to - jump.from}`)}
              </div>
            </div>
          );
        })}

        {/* The Horizontal Line */}
        <div className="relative h-1.5 bg-slate-400 rounded-full my-4">
          {/* Ticks */}
          {ticks.map((val) => {
            const pct = getPercent(val);
            return (
              <div
                key={val}
                className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center"
                style={{ left: `${pct}%` }}
              >
                <div className="w-0.5 h-3 bg-slate-600 mb-1" />
                <span className="text-[11px] font-mono text-slate-600 font-medium">{val}</span>
              </div>
            );
          })}

          {/* Interactive Draggable Frog Marker */}
          <div
            className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center z-20"
            style={{ left: `${getPercent(currentVal)}%` }}
          >
            <div className="w-6 h-6 rounded-full bg-emerald-600 border-2 border-white shadow-md flex items-center justify-center text-xs text-white">
              🐸
            </div>
            <span className="text-[10px] font-bold font-mono text-emerald-800 bg-white px-1.5 py-0.5 rounded border border-emerald-300 shadow-2xs mt-1">
              {currentVal}
            </span>
          </div>
        </div>

        {/* Slider input underneath to manipulate marker smoothly */}
        <div className="mt-8">
          <input
            type="range"
            min={safeStart}
            max={safeEnd}
            value={currentVal}
            onChange={(e) => setCurrentVal(Number(e.target.value))}
            className="w-full accent-emerald-600"
          />
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 6. TEN FRAME VIEW
// =========================================================================
export const TenFrameView: React.FC<{
  frames: Array<{ count: number; total: number; color?: string }>;
}> = ({ frames }) => {
  const [activeFrames, setActiveFrames] = useState(
    frames.length > 0 ? frames : [{ count: 7, total: 10, color: 'blue' }]
  );

  const toggleDot = (frameIdx: number, dotIdx: number) => {
    setActiveFrames((prev) =>
      prev.map((f, i) => {
        if (i !== frameIdx) return f;
        const newCount = dotIdx < f.count ? dotIdx : dotIdx + 1;
        return { ...f, count: newCount };
      })
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>Ten-Frame Counting (Tap any dot to explore addition / subtraction)</span>
        <span>
          Total Count: <strong className="text-slate-800">{activeFrames.reduce((acc, f) => acc + f.count, 0)}</strong>
        </span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {activeFrames.map((frame, frameIdx) => (
          <div key={frameIdx} className="bg-slate-50 border border-slate-200 rounded-xl p-3">
            <div className="flex justify-between items-center mb-2 text-xs font-medium text-slate-600">
              <span>Frame {frameIdx + 1}</span>
              <span className="font-mono text-slate-700">{frame.count} / 10</span>
            </div>
            <div className="grid grid-cols-5 grid-rows-2 gap-1.5 p-1.5 bg-white border border-slate-300 rounded-lg">
              {Array.from({ length: 10 }).map((_, dotIdx) => {
                const isFilled = dotIdx < frame.count;
                return (
                  <button
                    key={dotIdx}
                    onClick={() => toggleDot(frameIdx, dotIdx)}
                    className={`aspect-square rounded-full flex items-center justify-center transition-all ${
                      isFilled
                        ? 'bg-amber-500 text-white shadow-xs scale-95'
                        : 'border-2 border-dashed border-slate-200 hover:border-slate-300 bg-slate-50/50'
                    }`}
                    title={isFilled ? `Counter #${dotIdx + 1}` : 'Empty spot'}
                  >
                    {isFilled && <span className="text-[10px] font-bold">{dotIdx + 1}</span>}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// =========================================================================
// 7. MULTIPLICATION ARRAY VIEW
// =========================================================================
export const MultiplicationArrayView: React.FC<{
  rows: number;
  cols: number;
  total: number;
  rowLabel: string;
  colLabel: string;
}> = ({ rows, cols, total, rowLabel, colLabel }) => {
  const [hoveredCell, setHoveredCell] = useState<{ r: number; c: number } | null>(null);

  const safeRows = Math.min(12, Math.max(1, rows));
  const safeCols = Math.min(15, Math.max(1, cols));

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>Multiplication Array Model (Rows × Columns)</span>
        <span className="font-mono text-slate-800 font-semibold">
          {safeRows} × {safeCols} = {total || safeRows * safeCols}
        </span>
      </div>

      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl overflow-x-auto">
        <div className="inline-block min-w-full">
          <div className="text-center text-xs font-medium text-slate-600 mb-2">
            ▲ {colLabel || `${safeCols} items per row`}
          </div>

          <div className="flex items-center gap-3">
            <div className="text-xs font-medium text-slate-600 -rotate-90 origin-center whitespace-nowrap">
              ◄ {rowLabel || `${safeRows} rows`}
            </div>

            <div
              className="grid gap-1.5 p-2 bg-white border border-slate-300 rounded-lg"
              style={{
                gridTemplateColumns: `repeat(${safeCols}, minmax(18px, 28px))`,
              }}
            >
              {Array.from({ length: safeRows }).map((_, r) =>
                Array.from({ length: safeCols }).map((_, c) => {
                  const isHovered =
                    hoveredCell !== null && r <= hoveredCell.r && c <= hoveredCell.c;
                  return (
                    <button
                      key={`${r}-${c}`}
                      onMouseEnter={() => setHoveredCell({ r, c })}
                      onMouseLeave={() => setHoveredCell(null)}
                      className={`aspect-square rounded-md flex items-center justify-center text-[10px] font-bold transition-colors ${
                        isHovered
                          ? 'bg-amber-500 text-white scale-105'
                          : 'bg-blue-100 hover:bg-blue-200 text-blue-800'
                      }`}
                      title={`Row ${r + 1}, Col ${c + 1} (Item #${r * safeCols + c + 1})`}
                    >
                      {r * safeCols + c + 1}
                    </button>
                  );
                })
              )}
            </div>
          </div>

          <div className="mt-2 text-center text-xs text-slate-500">
            {hoveredCell ? (
              <span>
                Selected area: {hoveredCell.r + 1} × {hoveredCell.c + 1} ={' '}
                <strong className="text-amber-700">{(hoveredCell.r + 1) * (hoveredCell.c + 1)}</strong> items
              </span>
            ) : (
              <span>Hover over squares to see row × column grouping in real time</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 8. BALANCE SCALE VIEW
// =========================================================================
export const BalanceScaleView: React.FC<{
  leftSide: string;
  rightSide: string;
  variable: string;
  value: number | string;
}> = ({ leftSide, rightSide, variable, value }) => {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>Algebra Balance Scale (Both sides stay equal!)</span>
        <span className="font-mono text-emerald-700 font-semibold">Balanced =</span>
      </div>

      <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 text-center">
        <div className="relative max-w-md mx-auto pt-4 pb-2">
          <div className="h-2 bg-slate-700 rounded-full relative">
            <div className="absolute left-1/2 -top-1 -translate-x-1/2 w-4 h-4 bg-amber-500 rounded-full border-2 border-white shadow-xs" />

            <div className="absolute left-4 top-2 flex flex-col items-center">
              <div className="w-0.5 h-8 bg-slate-400" />
              <div className="w-28 sm:w-36 bg-white border-2 border-indigo-400 rounded-xl p-2.5 shadow-xs">
                <div className="text-xs text-indigo-700 font-semibold mb-1">Left Side</div>
                <div className="text-sm font-bold font-mono text-slate-900 bg-indigo-50/80 py-1 px-2 rounded">
                  {leftSide}
                </div>
              </div>
            </div>

            <div className="absolute right-4 top-2 flex flex-col items-center">
              <div className="w-0.5 h-8 bg-slate-400" />
              <div className="w-28 sm:w-36 bg-white border-2 border-emerald-400 rounded-xl p-2.5 shadow-xs">
                <div className="text-xs text-emerald-700 font-semibold mb-1">Right Side</div>
                <div className="text-sm font-bold font-mono text-slate-900 bg-emerald-50/80 py-1 px-2 rounded">
                  {rightSide}
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center mt-20">
            <div className="w-3 h-10 bg-slate-600 rounded-t" />
            <div className="w-20 h-3 bg-slate-700 rounded-full" />
          </div>
        </div>

        <div className="mt-4 inline-flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2 rounded-xl text-xs font-medium">
          <Sparkles className="w-4 h-4 text-emerald-600" />
          <span>
            Balanced Solution: <strong>{variable} = {value}</strong>
          </span>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 9. BAR COMPARISON VIEW
// =========================================================================
export const BarComparisonView: React.FC<{
  bars: Array<{ label: string; value: number; color?: string }>;
}> = ({ bars }) => {
  const safeBars = bars.length > 0 ? bars : [
    { label: 'First Quantity', value: 18 },
    { label: 'Second Quantity', value: 12 },
  ];
  const maxVal = Math.max(...safeBars.map((b) => b.value), 1);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>Bar Model / Tape Diagram Comparison</span>
        <span>Relative Proportions</span>
      </div>

      <div className="space-y-3 bg-slate-50 border border-slate-200 rounded-xl p-4">
        {safeBars.map((bar, idx) => {
          const pct = Math.max(8, Math.round((bar.value / maxVal) * 100));
          return (
            <div key={idx} className="space-y-1">
              <div className="flex justify-between text-xs font-medium text-slate-700">
                <span>{bar.label}</span>
                <span className="font-mono font-bold text-slate-900">{bar.value}</span>
              </div>
              <div className="h-8 bg-slate-200 rounded-lg overflow-hidden flex">
                <div
                  className="h-full bg-blue-600 text-white font-mono text-xs font-bold flex items-center px-3 transition-all rounded-lg"
                  style={{ width: `${pct}%` }}
                >
                  {bar.value}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// =========================================================================
// 10. PIE CHART VIEW
// =========================================================================
export const PieChartView: React.FC<{
  slices: Array<{ label: string; fraction: string; percentage: number; color?: string }>;
}> = ({ slices }) => {
  const safeSlices = slices.length > 0 ? slices : [
    { label: 'Part A', fraction: '3/8', percentage: 37.5 },
    { label: 'Part B', fraction: '5/8', percentage: 62.5 },
  ];

  const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

  let cumulative = 0;
  const gradientStops = safeSlices.map((slice, i) => {
    const start = cumulative;
    cumulative += slice.percentage;
    const color = slice.color || colors[i % colors.length];
    return `${color} ${start}% ${cumulative}%`;
  }).join(', ');

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>Fraction of a Whole (Circle Model)</span>
        <span>Total: 100%</span>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-6 bg-slate-50 border border-slate-200 rounded-xl p-4">
        <div
          className="w-32 h-32 rounded-full border-4 border-white shadow-sm shrink-0"
          style={{ background: `conic-gradient(${gradientStops})` }}
        />

        <div className="space-y-2 flex-1">
          {safeSlices.map((slice, i) => (
            <div key={i} className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span
                  className="w-3 h-3 rounded-full shrink-0"
                  style={{ backgroundColor: slice.color || colors[i % colors.length] }}
                />
                <span className="font-medium text-slate-700">{slice.label}</span>
              </div>
              <div className="font-mono text-slate-900 font-semibold">
                {slice.fraction} ({slice.percentage}%)
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// 11. GRADE 9 COORDINATE GRAPH VIEW (Slope-Intercept y = mx + b)
// =========================================================================
export const CoordinateGraphView: React.FC<{
  initialSlope?: number;
  initialIntercept?: number;
  lineEquation?: string;
  points?: Array<{ x: number; y: number; label?: string }>;
}> = ({ initialSlope = 2, initialIntercept = -1, lineEquation, points = [] }) => {
  const [slope, setSlope] = useState<number>(initialSlope);
  const [intercept, setIntercept] = useState<number>(initialIntercept);

  // SVG coordinate transform: box is 300x300, center is (150, 150), range is -6 to +6 (25px per unit)
  const scale = 25;
  const toSvgX = (x: number) => 150 + x * scale;
  const toSvgY = (y: number) => 150 - y * scale;

  // Calculate two points for the line
  const x1 = -6;
  const y1 = slope * x1 + intercept;
  const x2 = 6;
  const y2 = slope * x2 + intercept;

  // Intercept point
  const interceptSvg = { x: toSvgX(0), y: toSvgY(intercept) };

  // Sample points on the line
  const point1 = { x: 1, y: slope * 1 + intercept };
  const point2 = { x: -1, y: slope * -1 + intercept };

  return (
    <div className="space-y-4">
      {/* Instructions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1.5 font-medium">
          <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
          <span>
            Grade 9 Coordinate Plane: Adjust slope (m) to change steepness, and y-intercept (b) to move the line up or down!
          </span>
        </div>
        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          <button
            onClick={() => {
              setSlope(1);
              setIntercept(0);
            }}
            className="px-2 py-0.5 bg-white border border-slate-200 rounded text-[11px] font-semibold text-slate-700 hover:bg-slate-100"
          >
            y = x
          </button>
          <button
            onClick={() => {
              setSlope(-2);
              setIntercept(3);
            }}
            className="px-2 py-0.5 bg-white border border-slate-200 rounded text-[11px] font-semibold text-slate-700 hover:bg-slate-100"
          >
            y = -2x + 3
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-stretch">
        {/* SVG Coordinate Grid (2 cols on md) */}
        <div className="md:col-span-2 bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col items-center justify-center min-h-[320px] relative overflow-hidden">
          <svg width={300} height={300} viewBox="0 0 300 300" className="overflow-hidden bg-white rounded-xl shadow-xs border border-slate-200">
            {/* Grid lines */}
            {[-5, -4, -3, -2, -1, 1, 2, 3, 4, 5].map((val) => (
              <React.Fragment key={val}>
                {/* Vertical grid line */}
                <line
                  x1={toSvgX(val)}
                  y1={0}
                  x2={toSvgX(val)}
                  y2={300}
                  stroke="#e2e8f0"
                  strokeWidth={1}
                />
                {/* Horizontal grid line */}
                <line
                  x1={0}
                  y1={toSvgY(val)}
                  x2={300}
                  y2={toSvgY(val)}
                  stroke="#e2e8f0"
                  strokeWidth={1}
                />
                {/* Tick label */}
                <text x={toSvgX(val)} y={162} fontSize={9} fill="#94a3b8" textAnchor="middle">
                  {val}
                </text>
                <text x={140} y={toSvgY(val) + 3} fontSize={9} fill="#94a3b8" textAnchor="end">
                  {val}
                </text>
              </React.Fragment>
            ))}

            {/* Axes */}
            <line x1={0} y1={150} x2={300} y2={150} stroke="#475569" strokeWidth={2} />
            <line x1={150} y1={0} x2={150} y2={300} stroke="#475569" strokeWidth={2} />

            {/* Axis labels */}
            <text x={290} y={142} fontSize={11} fontWeight="bold" fill="#334155">
              x
            </text>
            <text x={156} y={15} fontSize={11} fontWeight="bold" fill="#334155">
              y
            </text>

            {/* The Linear Line */}
            <line
              x1={toSvgX(x1)}
              y1={toSvgY(y1)}
              x2={toSvgX(x2)}
              y2={toSvgY(y2)}
              stroke="#2563eb"
              strokeWidth={3}
            />

            {/* Y-intercept Point (0, b) */}
            <circle cx={interceptSvg.x} cy={interceptSvg.y} r={5} fill="#dc2626" />
            <text
              x={interceptSvg.x + 8}
              y={interceptSvg.y - 6}
              fontSize={10}
              fontWeight="bold"
              fill="#dc2626"
            >
              (0, {intercept})
            </text>

            {/* Additional Points */}
            <circle cx={toSvgX(point1.x)} cy={toSvgY(point1.y)} r={4} fill="#2563eb" />
            <circle cx={toSvgX(point2.x)} cy={toSvgY(point2.y)} r={4} fill="#2563eb" />

            {/* Custom given points if provided */}
            {points.map((pt, i) => (
              <React.Fragment key={i}>
                <circle cx={toSvgX(pt.x)} cy={toSvgY(pt.y)} r={4.5} fill="#059669" />
                <text
                  x={toSvgX(pt.x) + 6}
                  y={toSvgY(pt.y) - 6}
                  fontSize={10}
                  fontWeight="bold"
                  fill="#059669"
                >
                  {pt.label || `(${pt.x}, ${pt.y})`}
                </text>
              </React.Fragment>
            ))}
          </svg>

          <span className="text-[11px] text-slate-500 mt-2 font-mono">
            Origin: (0,0) · Scale: 1 grid unit = 1
          </span>
        </div>

        {/* Controls & Equation Breakdown (1 col) */}
        <div className="space-y-4 flex flex-col justify-between">
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-4">
            <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Slope-Intercept Controls
            </h5>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-medium text-slate-700">
                <span>Slope (m = Rise/Run):</span>
                <strong className="font-mono text-blue-700">{slope}</strong>
              </div>
              <input
                type="range"
                min={-4}
                max={4}
                step={0.5}
                value={slope}
                onChange={(e) => setSlope(Number(e.target.value))}
                className="w-full accent-blue-600"
              />
              <span className="text-[10px] text-slate-500 block">
                {slope > 0 ? '↗ Slanting up (positive)' : slope < 0 ? '↘ Slanting down (negative)' : 'Horizontal line (m = 0)'}
              </span>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-medium text-slate-700">
                <span>y-Intercept (b):</span>
                <strong className="font-mono text-rose-700">{intercept}</strong>
              </div>
              <input
                type="range"
                min={-5}
                max={5}
                step={0.5}
                value={intercept}
                onChange={(e) => setIntercept(Number(e.target.value))}
                className="w-full accent-rose-600"
              />
              <span className="text-[10px] text-slate-500 block">
                Crosses y-axis at (0, {intercept})
              </span>
            </div>
          </div>

          {/* Equation Card */}
          <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-4 space-y-2 text-xs">
            <div className="font-bold text-blue-950 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Slope-Intercept Form</span>
            </div>
            <div className="text-base font-bold font-mono text-blue-900 bg-white p-2.5 rounded-xl border border-blue-200 text-center">
              y = {slope !== 1 && slope !== -1 ? slope : slope === -1 ? '-' : ''}x{' '}
              {intercept > 0 ? `+ ${intercept}` : intercept < 0 ? `- ${Math.abs(intercept)}` : ''}
            </div>
            <div className="text-slate-700 text-[11px] space-y-0.5 pt-1">
              <div>• Slope (m): <strong>{slope}</strong></div>
              <div>• y-Intercept (b): <strong>(0, {intercept})</strong></div>
              <div>• Point at x = 1: <strong>(1, {slope * 1 + intercept})</strong></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Default fallback
const DefaultVisualFallback: React.FC<{ model: VisualModel }> = ({ model }) => {
  return (
    <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600">
      <p className="font-medium mb-1">Visual Concept Representation:</p>
      <pre className="font-mono text-[11px] bg-white p-2 rounded border border-slate-200 overflow-x-auto">
        {JSON.stringify(model.params, null, 2)}
      </pre>
    </div>
  );
};

