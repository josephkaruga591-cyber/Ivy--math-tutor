import React, { useState, useEffect } from 'react';
import { GradeLevel, PracticeProblem, CheckAnswerResult } from '../types';
import { Sparkles, CheckCircle, XCircle, RefreshCw, HelpCircle, ArrowLeft, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';

interface PracticeLabProps {
  topic: string;
  gradeLevel: GradeLevel;
  originalProblem: string;
  onBackToSolver: () => void;
}

export const PracticeLab: React.FC<PracticeLabProps> = ({
  topic,
  gradeLevel,
  originalProblem,
  onBackToSolver,
}) => {
  const [practiceProblem, setPracticeProblem] = useState<PracticeProblem | null>(null);
  const [isLoadingPractice, setIsLoadingPractice] = useState<boolean>(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showAnswer, setShowAnswer] = useState<boolean>(false);
  const [revealedHint, setRevealedHint] = useState<boolean>(false);

  // Check work state
  const [customAnswer, setCustomAnswer] = useState<string>('');
  const [isCheckingWork, setIsCheckingWork] = useState<boolean>(false);
  const [checkResult, setCheckResult] = useState<CheckAnswerResult | null>(null);

  // Fetch practice problem
  const fetchNewPractice = async () => {
    setIsLoadingPractice(true);
    setSelectedOption(null);
    setShowAnswer(false);
    setRevealedHint(false);

    try {
      const res = await fetch('/api/math/generate-practice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          gradeLevel,
          basedOnProblem: originalProblem,
        }),
      });

      if (!res.ok) throw new Error('Failed to generate practice');
      const data = await res.json();
      setPracticeProblem(data);
    } catch (err) {
      console.error(err);
      // Fallback
      setPracticeProblem({
        problemText: `Practice Question: If a teacher distributes 24 pencils equally among 6 students, how many pencils does each student receive?`,
        options: ['3 pencils', '4 pencils', '5 pencils', '6 pencils'],
        correctAnswer: '4 pencils',
        explanation: 'Divide total pencils by students: 24 ÷ 6 = 4 pencils each!',
        hint: 'Think about what number times 6 equals 24.',
      });
    } finally {
      setIsLoadingPractice(false);
    }
  };

  useEffect(() => {
    fetchNewPractice();
  }, [topic, gradeLevel]);

  const handleSelectOption = (opt: string) => {
    if (selectedOption !== null) return;
    setSelectedOption(opt);
    setShowAnswer(true);

    if (practiceProblem && opt === practiceProblem.correctAnswer) {
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.7 },
      });
    }
  };

  // Handle checking custom student answer
  const handleCheckCustomAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customAnswer.trim()) return;

    setIsCheckingWork(true);
    setCheckResult(null);

    try {
      const res = await fetch('/api/math/check-work', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          originalProblem,
          studentAnswer: customAnswer.trim(),
          gradeLevel,
        }),
      });

      if (!res.ok) throw new Error('Failed to check answer');
      const data = await res.json();
      setCheckResult(data);

      if (data.isCorrect) {
        confetti({
          particleCount: 60,
          spread: 80,
          origin: { y: 0.7 },
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsCheckingWork(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-200">
        <button
          onClick={onBackToSolver}
          className="flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Step-by-Step Solution</span>
        </button>
        <span className="text-xs text-slate-500 font-medium">
          Practice Lab · {topic}
        </span>
      </div>

      {/* Section 1: Practice Problem Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <Trophy className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Try a Similar Practice Problem</h3>
              <p className="text-xs text-slate-500">Test your understanding with instant feedback</p>
            </div>
          </div>

          <button
            onClick={fetchNewPractice}
            disabled={isLoadingPractice}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingPractice ? 'animate-spin' : ''}`} />
            <span>New Problem</span>
          </button>
        </div>

        {isLoadingPractice ? (
          <div className="py-12 text-center text-slate-500 text-xs">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-blue-600" />
            <span>Generating fresh grade-level problem...</span>
          </div>
        ) : practiceProblem ? (
          <div className="space-y-4">
            {/* Problem text */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-sm sm:text-base font-semibold text-slate-900">
              {practiceProblem.problemText}
            </div>

            {/* Multiple Choice Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {practiceProblem.options.map((option, idx) => {
                const isSelected = selectedOption === option;
                const isCorrect = option === practiceProblem.correctAnswer;
                let btnStyle = 'bg-white border-slate-300 text-slate-800 hover:border-blue-400 hover:bg-blue-50/30';

                if (showAnswer) {
                  if (isCorrect) {
                    btnStyle = 'bg-emerald-50 border-emerald-500 text-emerald-900 font-bold';
                  } else if (isSelected) {
                    btnStyle = 'bg-rose-50 border-rose-400 text-rose-900';
                  } else {
                    btnStyle = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
                  }
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(option)}
                    disabled={showAnswer}
                    className={`p-4 rounded-xl border-2 text-left text-xs sm:text-sm transition-all flex items-center justify-between ${btnStyle}`}
                  >
                    <span>{option}</span>
                    {showAnswer && isCorrect && <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />}
                    {showAnswer && isSelected && !isCorrect && <XCircle className="w-4 h-4 text-rose-600 shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Hint toggle */}
            {!showAnswer && (
              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => setRevealedHint(!revealedHint)}
                  className="flex items-center gap-1.5 text-xs text-amber-700 hover:text-amber-800 font-medium"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>{revealedHint ? 'Hide Hint' : 'Need a hint?'}</span>
                </button>
              </div>
            )}

            {revealedHint && !showAnswer && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
                <strong>Hint:</strong> {practiceProblem.hint}
              </div>
            )}

            {/* Feedback & Explanation Card */}
            {showAnswer && (
              <div
                className={`p-4 rounded-xl border space-y-2 ${
                  selectedOption === practiceProblem.correctAnswer
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                    : 'bg-amber-50 border-amber-200 text-amber-950'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-xs sm:text-sm">
                  {selectedOption === practiceProblem.correctAnswer ? (
                    <>
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      <span>Spot on! Great work!</span>
                    </>
                  ) : (
                    <>
                      <HelpCircle className="w-4 h-4 text-amber-600" />
                      <span>Good try! Let's see how it works:</span>
                    </>
                  )}
                </div>
                <p className="text-xs sm:text-sm leading-relaxed">
                  {practiceProblem.explanation}
                </p>
                <div className="pt-2">
                  <button
                    onClick={fetchNewPractice}
                    className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors"
                  >
                    Try Another One
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : null}
      </div>

      {/* Section 2: Check Your Own Homework Answer */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
        <div>
          <h3 className="text-base font-bold text-slate-900">Check Your Own Answer</h3>
          <p className="text-xs text-slate-500">
            Did you solve the problem on paper first? Type your answer here to have StepWise check your work!
          </p>
        </div>

        <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600">
          <strong>Checking for problem:</strong> {originalProblem}
        </div>

        <form onSubmit={handleCheckCustomAnswer} className="space-y-3">
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={customAnswer}
              onChange={(e) => setCustomAnswer(e.target.value)}
              placeholder="e.g. '18 cookies' or 'x = 5' or '3/4'"
              className="flex-1 text-sm p-3 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 bg-white"
            />
            <button
              type="submit"
              disabled={isCheckingWork || !customAnswer.trim()}
              className="px-6 py-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 rounded-xl shadow-xs transition-colors shrink-0"
            >
              {isCheckingWork ? 'Checking...' : 'Check My Work'}
            </button>
          </div>
        </form>

        {checkResult && (
          <div
            className={`p-4 rounded-xl border space-y-1.5 ${
              checkResult.isCorrect
                ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                : 'bg-amber-50 border-amber-200 text-amber-950'
            }`}
          >
            <div className="flex items-center gap-2 font-bold text-xs sm:text-sm">
              {checkResult.isCorrect ? (
                <>
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>Correct! Outstanding job!</span>
                </>
              ) : (
                <>
                  <HelpCircle className="w-4 h-4 text-amber-600" />
                  <span>Almost there! Check this out:</span>
                </>
              )}
            </div>
            <p className="text-xs sm:text-sm leading-relaxed">{checkResult.feedback}</p>
            {!checkResult.isCorrect && (
              <div className="text-xs text-slate-600 pt-1">
                The expected answer is: <strong className="text-slate-900">{checkResult.correctAnswer}</strong>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
