import React from 'react';
import { MathSolution } from '../types';
import { Bookmark, X, Trash2, ArrowRight } from 'lucide-react';

interface SavedProblemsModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedSolutions: MathSolution[];
  onSelectSolution: (solution: MathSolution) => void;
  onDeleteSolution: (id: string) => void;
}

export const SavedProblemsModal: React.FC<SavedProblemsModalProps> = ({
  isOpen,
  onClose,
  savedSolutions,
  onSelectSolution,
  onDeleteSolution,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-xl w-full max-h-[80vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center">
              <Bookmark className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">My Solved Homework Notebook</h3>
              <p className="text-xs text-slate-500">{savedSolutions.length} saved math problems</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* List */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {savedSolutions.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No saved problems yet. Click the bookmark icon on any solved problem to save it to your notebook!
            </div>
          ) : (
            savedSolutions.map((item) => (
              <div
                key={item.id || item.originalProblem}
                className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl hover:border-blue-300 transition-colors flex items-center justify-between gap-3 group"
              >
                <div
                  className="flex-1 cursor-pointer"
                  onClick={() => {
                    onSelectSolution(item);
                    onClose();
                  }}
                >
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                    <span className="font-semibold text-slate-700">{item.topic}</span>
                    <span aria-hidden="true">·</span>
                    <span className="capitalize">{item.gradeLevel.replace('_', ' ')}</span>
                  </div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1 group-hover:text-blue-600">
                    {item.originalProblem}
                  </h4>
                  <div className="text-xs text-emerald-700 font-semibold mt-1">
                    Answer: {item.finalAnswer}
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => {
                      onSelectSolution(item);
                      onClose();
                    }}
                    className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg text-xs flex items-center gap-1 font-semibold"
                    title="Open solution"
                  >
                    <span>View</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => item.id && onDeleteSolution(item.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"
                    title="Remove from notebook"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
