import React, { useMemo } from 'react';
import katex from 'katex';

interface KatexMathProps {
  math: string;
  block?: boolean;
  className?: string;
}

export const KatexMath: React.FC<KatexMathProps> = ({ math, block = false, className = '' }) => {
  const html = useMemo(() => {
    if (!math) return '';

    // Clean up math text for KaTeX
    let cleaned = math.trim();

    // If it's already surrounded with $ or $$, strip them for KaTeX
    if (cleaned.startsWith('$$') && cleaned.endsWith('$$')) {
      cleaned = cleaned.slice(2, -2).trim();
    } else if (cleaned.startsWith('$') && cleaned.endsWith('$')) {
      cleaned = cleaned.slice(1, -1).trim();
    }

    try {
      return katex.renderToString(cleaned, {
        displayMode: block,
        throwOnError: false,
        strict: false,
      });
    } catch {
      return null;
    }
  }, [math, block]);

  if (!html) {
    return <span className={`font-mono text-slate-900 ${className}`}>{math}</span>;
  }

  return (
    <span
      className={`inline-block ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};
