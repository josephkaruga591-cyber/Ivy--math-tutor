import React from 'react';
import { GradeLevel } from '../types';
import { Sparkles, BookOpen } from 'lucide-react';

interface SampleProblemsProps {
  gradeLevel: GradeLevel;
  onSelectProblem: (problemText: string, grade: GradeLevel) => void;
}

interface SampleItem {
  grade: GradeLevel;
  topic: string;
  problem: string;
  tag: string;
}

const SAMPLE_PROBLEMS: SampleItem[] = [
  // Grades 1-2
  {
    grade: 'grades_1_2',
    topic: 'Addition with Regrouping',
    tag: 'Word Problem',
    problem: 'Maya has 7 stickers. Her brother gives her 8 more stickers. How many stickers does Maya have in total?',
  },
  {
    grade: 'grades_1_2',
    topic: 'Subtraction from a Two-Digit Number',
    tag: 'Word Problem',
    problem: 'There were 23 birds sitting on a tree branch. 9 birds flew away. How many birds are still on the tree?',
  },
  {
    grade: 'grades_1_2',
    topic: 'Basic Grouping & Sharing',
    tag: 'Sharing Story',
    problem: 'Leo has 12 toy cars and wants to put them into 3 equal boxes. How many toy cars go into each box?',
  },

  // Grades 3-4
  {
    grade: 'grades_3_4',
    topic: 'Multiplication Array & Groups',
    tag: 'Array Model',
    problem: 'A bakery bakes 6 trays of muffins. Each tray holds 8 muffins. How many muffins did they bake in all?',
  },
  {
    grade: 'grades_3_4',
    topic: 'Fractions on a Pizza',
    tag: 'Fraction Strip',
    problem: 'Liam ate 3/4 of a mini pizza and Zoe ate 1/2 of her mini pizza. Who ate more, and what is the difference?',
  },
  {
    grade: 'grades_3_4',
    topic: 'Division with Remainder',
    tag: 'Real-World Logic',
    problem: 'There are 29 students going on a field trip in vans. Each van holds 6 students. How many vans are needed so everyone has a seat?',
  },
  {
    grade: 'grades_3_4',
    topic: 'Area of a Rectangle',
    tag: 'Geometry',
    problem: 'A rectangular playground is 9 meters long and 4 meters wide. What is its total area in square meters?',
  },

  // Grades 5-6
  {
    grade: 'grades_5_6',
    topic: 'Adding Unlike Fractions',
    tag: 'Fractions',
    problem: 'Calculate: 2/3 + 1/4. Show common denominator steps and simplified final fraction.',
  },
  {
    grade: 'grades_5_6',
    topic: 'Order of Operations (PEMDAS)',
    tag: 'PEMDAS',
    problem: 'Evaluate step by step: 18 - 3 * (4 + 2) / 2',
  },
  {
    grade: 'grades_5_6',
    topic: 'Decimals & Money Word Problem',
    tag: 'Real World Money',
    problem: 'Sophia bought a notebook for $4.75 and 3 pens for $1.50 each. If she paid with a $20 bill, how much change did she receive?',
  },
  {
    grade: 'grades_5_6',
    topic: 'Percentages & Discounts',
    tag: 'Percentages',
    problem: 'A bicycle costs $160 and is on sale for 25% off. What is the sale price of the bicycle?',
  },

  // Grades 7-8
  {
    grade: 'grades_7_8',
    topic: 'Solving Two-Step Linear Equation',
    tag: 'Pre-Algebra',
    problem: 'Solve for x: 3x + 7 = 28',
  },
  {
    grade: 'grades_7_8',
    topic: 'Negative Integers Arithmetic',
    tag: 'Integers',
    problem: 'Evaluate step by step: -15 - (-8) + (-4) * 3',
  },
  {
    grade: 'grades_7_8',
    topic: 'Ratio & Proportions Recipe',
    tag: 'Proportions',
    problem: 'A lemonade recipe uses 4 cups of water for every 3 lemons. How many lemons do you need for 16 cups of water?',
  },
  {
    grade: 'grades_7_8',
    topic: 'Pythagorean Theorem',
    tag: 'Geometry',
    problem: 'A right-angled triangle has legs of length 6 cm and 8 cm. What is the length of the hypotenuse?',
  },

  // Grade 9 (Algebra 1)
  {
    grade: 'grade_9',
    topic: 'Factoring Quadratic Trinomials',
    tag: 'Algebra 1',
    problem: 'Solve by factoring: x^2 + 7x + 12 = 0. Show the two binomial factors and both solutions for x.',
  },
  {
    grade: 'grade_9',
    topic: 'System of Linear Equations',
    tag: 'Systems',
    problem: 'Solve the system of equations using elimination or substitution: 2x + y = 9 and x - y = 3. Find both x and y.',
  },
  {
    grade: 'grade_9',
    topic: 'Slope-Intercept Form & Graphing',
    tag: 'Linear Functions',
    problem: 'Graph the line y = 2x - 3. Identify the slope m, the y-intercept b, and calculate two points on the line.',
  },
  {
    grade: 'grade_9',
    topic: 'Multiplying Binomials (FOIL Method)',
    tag: 'Polynomials',
    problem: 'Expand and simplify using FOIL: (2x + 3)(x - 4)',
  },
  {
    grade: 'grade_9',
    topic: 'Simplifying Square Roots & Radicals',
    tag: 'Radicals',
    problem: 'Simplify the radical expression completely: √(72) + 3√(2)',
  },
];

export const SampleProblems: React.FC<SampleProblemsProps> = ({
  gradeLevel,
  onSelectProblem,
}) => {
  const currentGradeSamples = SAMPLE_PROBLEMS.filter((s) => s.grade === gradeLevel);

  return (
    <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-blue-600" />
          <h3 className="text-sm font-bold text-slate-900">Try Grade School Examples</h3>
        </div>
        <span className="text-xs text-slate-500">1-click to solve & explain</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {currentGradeSamples.map((item, idx) => (
          <button
            key={idx}
            onClick={() => onSelectProblem(item.problem, item.grade)}
            className="p-3.5 rounded-xl border border-slate-200 hover:border-blue-400 bg-slate-50/50 hover:bg-blue-50/20 text-left transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
                <span className="font-semibold text-slate-700">{item.topic}</span>
                <span className="text-[11px] text-blue-600 font-medium">{item.tag}</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-800 group-hover:text-blue-900 leading-snug line-clamp-2">
                {item.problem}
              </p>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-semibold text-blue-600 mt-2.5">
              <Sparkles className="w-3 h-3" />
              <span>Solve this example</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
