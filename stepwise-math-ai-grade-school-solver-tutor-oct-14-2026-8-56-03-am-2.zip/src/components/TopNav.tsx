import React from 'react';
import { Bookmark, Sparkles } from 'lucide-react';

interface TopNavProps {
  activeView: 'solver' | 'practice' | 'manipulatives';
  onNavigate: (view: 'solver' | 'practice' | 'manipulatives') => void;
  onOpenNotebook: () => void;
  savedCount: number;
  onNewProblem: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeView,
  onNavigate,
  onOpenNotebook,
  savedCount,
  onNewProblem,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element in display face) */}
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            onNavigate('solver');
          }}
          className="text-lg font-extrabold tracking-tight text-slate-900 whitespace-nowrap shrink-0 font-display flex items-center gap-2"
        >
          <span className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
            ∑
          </span>
          <span>StepWise Math</span>
        </a>

        {/* Zone 2: 4 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-xs font-semibold text-slate-600">
          <button
            onClick={() => onNavigate('solver')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeView === 'solver'
                ? 'text-blue-600 border-b-2 border-blue-600 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Math Solver
          </button>

          <button
            onClick={() => onNavigate('manipulatives')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeView === 'manipulatives'
                ? 'text-blue-600 border-b-2 border-blue-600 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Manipulatives Lab
          </button>

          <button
            onClick={() => onNavigate('practice')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeView === 'practice'
                ? 'text-blue-600 border-b-2 border-blue-600 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Practice Lab
          </button>

          <button
            onClick={onOpenNotebook}
            className="whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors flex items-center gap-1.5"
          >
            <Bookmark className="w-3.5 h-3.5 text-amber-500 fill-current" />
            <span>Notebook ({savedCount})</span>
          </button>
        </nav>

        {/* Zone 3: 1 primary action button */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onNewProblem}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>New Problem</span>
          </button>
        </div>
      </div>
    </header>
  );
};
