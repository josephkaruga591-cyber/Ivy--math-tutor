import React, { useState, useEffect } from 'react';
import { MathSolution } from '../types';
import { KatexMath } from './KatexMath';
import { VisualManipulatives } from './visuals/VisualManipulatives';
import {
  CheckCircle2,
  Volume2,
  VolumeX,
  Lightbulb,
  Printer,
  Bookmark,
  Share2,
  Sparkles,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  Eye,
  EyeOff,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface SolutionDisplayProps {
  solution: MathSolution;
  onOpenPractice: () => void;
  onSaveSolution: (sol: MathSolution) => void;
  isSaved?: boolean;
}

export const SolutionDisplay: React.FC<SolutionDisplayProps> = ({
  solution,
  onOpenPractice,
  onSaveSolution,
  isSaved = false,
}) => {
  const [revealedHints, setRevealedHints] = useState<number>(0);
  const [showSocraticMode, setShowSocraticMode] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [copiedAnswer, setCopiedAnswer] = useState<boolean>(false);

  // Trigger celebration confetti on initial load
  useEffect(() => {
    try {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.8 },
      });
    } catch {
      // safe fallback
    }
  }, [solution.originalProblem]);

  // Web Speech API for Read Aloud
  const handleToggleSpeech = () => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();

    // Build speech text from problem and steps
    const speechScript = `
      Let's solve this math problem.
      Question: ${solution.originalProblem}.
      What is asked: ${solution.whatIsAsked}.
      ${solution.steps.map((s) => `${s.title}. ${s.explanation}`).join('. ')}
      Final answer: ${solution.finalAnswer}.
      How to check your work: ${solution.checkYourWork}.
    `;

    const utterance = new SpeechSynthesisUtterance(speechScript);
    utterance.rate = 0.95; // Friendly, slightly paced for kids
    utterance.pitch = 1.05;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  // Cleanup speech on unmount
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleCopyAnswer = () => {
    navigator.clipboard.writeText(solution.finalAnswer);
    setCopiedAnswer(true);
    setTimeout(() => setCopiedAnswer(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 print:space-y-4">
      {/* Solution Header Card */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <span>{solution.topic}</span>
              <span aria-hidden="true">·</span>
              <span className="capitalize">{solution.gradeLevel.replace('_', ' ')}</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
              {solution.originalProblem}
            </h2>
          </div>

          {/* Action buttons (Read Aloud, Bookmark, Print) */}
          <div className="flex items-center gap-2 shrink-0 print:hidden">
            <button
              onClick={handleToggleSpeech}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                isSpeaking
                  ? 'bg-amber-100 text-amber-800 border-amber-300'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
              title="Listen to solution read aloud"
            >
              {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-blue-600" />}
              <span>{isSpeaking ? 'Stop Audio' : 'Read Aloud'}</span>
            </button>

            <button
              onClick={() => onSaveSolution(solution)}
              className={`p-2 rounded-lg border transition-colors ${
                isSaved
                  ? 'bg-amber-50 text-amber-600 border-amber-200'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
              title={isSaved ? 'Saved in My Notebook' : 'Save problem to Notebook'}
            >
              <Bookmark className="w-3.5 h-3.5 fill-current" />
            </button>

            <button
              onClick={handlePrint}
              className="p-2 rounded-lg border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 transition-colors"
              title="Print friendly worksheet"
            >
              <Printer className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Word Problem Breakdown: What is asked & Key Clues */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-1">
          <div className="bg-blue-50/60 border border-blue-100 rounded-xl p-3.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-blue-900 mb-1">
              <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
              <span>What is this problem asking?</span>
            </div>
            <p className="text-xs sm:text-sm text-blue-950 leading-relaxed">
              {solution.whatIsAsked}
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
            <div className="text-xs font-semibold text-slate-700 mb-1">
              Key Clues & Given Numbers:
            </div>
            <ul className="text-xs text-slate-600 space-y-1 list-disc list-inside">
              {solution.keyClues.map((clue, i) => (
                <li key={i}>{clue}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Socratic Hint-First Toggle */}
        {solution.hints && solution.hints.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowSocraticMode(!showSocraticMode)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  showSocraticMode
                    ? 'bg-amber-500 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {showSocraticMode ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5 text-amber-600" />}
                <span>{showSocraticMode ? 'Hint-First Mode: Active' : 'Try With Hints First'}</span>
              </button>
              <span className="text-xs text-slate-500 hidden sm:inline">
                Reveal clues one-by-one to solve it on your own!
              </span>
            </div>

            {showSocraticMode && (
              <div className="flex items-center gap-1.5">
                {[1, 2, 3].map((num) => (
                  <button
                    key={num}
                    onClick={() => setRevealedHints(num)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                      revealedHints >= num
                        ? 'bg-amber-100 text-amber-900 border border-amber-300 font-bold'
                        : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                    }`}
                  >
                    Hint {num}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Socratic Hints Revealed Box */}
        {showSocraticMode && revealedHints > 0 && (
          <div className="mt-3 p-4 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
              <Lightbulb className="w-4 h-4 text-amber-600" />
              <span>Socratic Hints ({revealedHints} of {solution.hints.length} revealed):</span>
            </div>
            {solution.hints.slice(0, revealedHints).map((hint, idx) => (
              <div key={idx} className="text-xs text-amber-950 pl-2 border-l-2 border-amber-300 py-0.5">
                <strong>Hint {idx + 1}:</strong> {hint}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Interactive Visual Manipulative (Ten frames, Fraction bars, Number lines, Balance scales, etc.) */}
      {solution.visualModel && (
        <VisualManipulatives model={solution.visualModel} topic={solution.topic} />
      )}

      {/* Step-by-Step Solution Breakdown Cards */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900">
            Step-by-Step Solution ({solution.steps.length} Steps)
          </h3>
          <span className="text-xs text-slate-500">Read each step carefully</span>
        </div>

        <div className="space-y-3.5">
          {solution.steps.map((step) => (
            <div
              key={step.stepNumber}
              className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs transition-shadow hover:shadow-sm"
            >
              {/* Step Header */}
              <div className="flex items-start gap-3">
                <div className="w-7 h-7 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  {step.stepNumber}
                </div>
                <div className="space-y-2 flex-1">
                  <h4 className="text-sm font-bold text-slate-900">
                    {step.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                    {step.explanation}
                  </p>

                  {/* Math Expression Block */}
                  {step.mathExpression && (
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 my-2 text-center overflow-x-auto">
                      <KatexMath math={step.mathExpression} block={true} className="text-sm sm:text-base text-slate-900" />
                    </div>
                  )}

                  {/* Tip or Watch Out */}
                  {step.tipOrWatchOut && (
                    <div className="flex items-start gap-2 bg-amber-50/70 border border-amber-200/80 rounded-xl p-2.5 text-xs text-amber-900 mt-2">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <strong>Watch Out!</strong> {step.tipOrWatchOut}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Final Answer Banner */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-6 text-white shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold text-emerald-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-200" />
            <span>Final Solved Answer</span>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold tracking-tight font-display">
            {solution.finalAnswer}
          </div>
          {solution.unit && (
            <div className="text-xs text-emerald-100">
              Unit: <strong>{solution.unit}</strong>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyAnswer}
            className="px-4 py-2 text-xs font-semibold text-emerald-950 bg-white rounded-xl shadow-xs hover:bg-emerald-50 transition-colors"
          >
            {copiedAnswer ? 'Copied!' : 'Copy Answer'}
          </button>
        </div>
      </div>

      {/* How to Check Your Work Card */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-900 mb-2">
          <Sparkles className="w-4 h-4 text-blue-600" />
          <span>How to Double-Check Your Answer (Self-Check Method)</span>
        </div>
        <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
          {solution.checkYourWork}
        </p>
      </div>

      {/* Bottom Action Strip: Try Similar Problem & Check My Answer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-5 bg-blue-50/80 border border-blue-200 rounded-2xl print:hidden">
        <div>
          <h4 className="text-sm font-bold text-blue-950">Mastered this concept?</h4>
          <p className="text-xs text-blue-800">
            Try a generated practice problem or check your own homework answer!
          </p>
        </div>

        <button
          onClick={onOpenPractice}
          className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors shrink-0"
        >
          <span>Try a Practice Problem</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
