import React, { useState, useRef } from 'react';
import { GradeLevel, ExplanationStyle } from '../types';
import { Calculator, Image as ImageIcon, Sparkles, X, BookOpen, Smile } from 'lucide-react';
import { Scratchpad } from './Scratchpad';

interface MathInputBarProps {
  onSolve: (problem: string, gradeLevel: GradeLevel, style: ExplanationStyle, imageBase64?: string) => void;
  isLoading: boolean;
  selectedGrade: GradeLevel;
  onGradeChange: (grade: GradeLevel) => void;
}

export const MathInputBar: React.FC<MathInputBarProps> = ({
  onSolve,
  isLoading,
  selectedGrade,
  onGradeChange,
}) => {
  const [inputMode, setInputMode] = useState<'type' | 'draw' | 'photo'>('type');
  const [problemText, setProblemText] = useState<string>('');
  const [style, setStyle] = useState<ExplanationStyle>('standard');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Grade level options (Grades 1-9)
  const gradeOptions: { id: GradeLevel; label: string; desc: string }[] = [
    { id: 'grades_1_2', label: 'Grades 1-2', desc: 'Counting, Addition, Subtraction' },
    { id: 'grades_3_4', label: 'Grades 3-4', desc: 'Multiply, Divide, Simple Fractions' },
    { id: 'grades_5_6', label: 'Grades 5-6', desc: 'Fractions, Decimals, PEMDAS' },
    { id: 'grades_7_8', label: 'Grades 7-8', desc: 'Pre-Algebra, Integers, Equations' },
    { id: 'grade_9', label: 'Grade 9', desc: 'Algebra 1, Quadratics, Systems, Functions' },
  ];

  // Quick Math Pad buttons
  const mathSymbols = [
    { label: '+', insert: ' + ' },
    { label: '−', insert: ' - ' },
    { label: '×', insert: ' × ' },
    { label: '÷', insert: ' ÷ ' },
    { label: '=', insert: ' = ' },
    { label: 'a/b', insert: ' / ' },
    { label: '( )', insert: '()' },
    { label: 'x²', insert: '^2' },
    { label: '√', insert: '√(' },
    { label: 'x', insert: 'x' },
    { label: 'y', insert: 'y' },
    { label: 'f(x)', insert: 'f(x)' },
    { label: '%', insert: '%' },
    { label: 'π', insert: 'π' },
  ];

  const handleInsertSymbol = (insertText: string) => {
    const textarea = textareaRef.current;
    if (!textarea) {
      setProblemText((prev) => prev + insertText);
      return;
    }

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const newText = problemText.slice(0, start) + insertText + problemText.slice(end);
    setProblemText(newText);

    setTimeout(() => {
      textarea.focus();
      const cursor = start + insertText.length;
      textarea.setSelectionRange(cursor, cursor);
    }, 10);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setUploadedImage(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!problemText.trim() && !uploadedImage) return;

    onSolve(problemText.trim(), selectedGrade, style, uploadedImage || undefined);
  };

  const handleSolveDrawing = (imageBase64: string) => {
    onSolve('', selectedGrade, style, imageBase64);
  };

  return (
    <div className="bg-white border border-slate-200/90 rounded-2xl shadow-xs p-5 md:p-6 space-y-5">
      {/* Grade Level Selector Segmented Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-sm font-semibold text-slate-900">Student Grade Band</h2>
          <p className="text-xs text-slate-500">Adapts explanation vocabulary, visual depth, and school curriculum</p>
        </div>

        {/* Grade band interactive segmented buttons */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100/90 rounded-xl">
          {gradeOptions.map((g) => {
            const isSelected = selectedGrade === g.id;
            return (
              <button
                key={g.id}
                type="button"
                onClick={() => onGradeChange(g.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
                  isSelected
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title={g.desc}
              >
                {g.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Input Mode Tabs: Type / Draw / Upload */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
          <button
            type="button"
            onClick={() => setInputMode('type')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              inputMode === 'type' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Calculator className="w-3.5 h-3.5 text-blue-600" />
            <span>Type or Paste Math</span>
          </button>

          <button
            type="button"
            onClick={() => setInputMode('draw')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              inputMode === 'draw' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Whiteboard Scratchpad</span>
          </button>

          <button
            type="button"
            onClick={() => setInputMode('photo')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              inputMode === 'photo' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
            <span>Upload Homework Photo</span>
          </button>
        </div>

        {/* Explanation Tone Selector */}
        <div className="flex items-center gap-1 text-xs text-slate-500">
          <span className="font-medium mr-1">Tutor Style:</span>
          <button
            type="button"
            onClick={() => setStyle('standard')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors ${
              style === 'standard'
                ? 'bg-blue-50 text-blue-700 font-semibold'
                : 'hover:bg-slate-100 text-slate-600'
            }`}
          >
            <BookOpen className="w-3 h-3" />
            <span>Step-by-Step</span>
          </button>
          <button
            type="button"
            onClick={() => setStyle('story')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors ${
              style === 'story'
                ? 'bg-amber-50 text-amber-800 font-semibold'
                : 'hover:bg-slate-100 text-slate-600'
            }`}
          >
            <Smile className="w-3 h-3 text-amber-600" />
            <span>Story & Analogy</span>
          </button>
        </div>
      </div>

      {/* Mode 1: Textarea with Math Pad */}
      {inputMode === 'type' && (
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="relative">
            <textarea
              ref={textareaRef}
              value={problemText}
              onChange={(e) => setProblemText(e.target.value)}
              placeholder="Type any math equation or grade school word problem here... (e.g. 'Emma baked 36 cookies and packed 4 in each box. How many boxes did she fill?' or '2/3 + 1/4' or '4x - 7 = 21')"
              rows={3}
              className="w-full p-3.5 text-sm sm:text-base border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 bg-white placeholder:text-slate-400 resize-none transition-all"
            />
            {problemText && (
              <button
                type="button"
                onClick={() => setProblemText('')}
                className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 p-1"
                title="Clear text"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick Math Pad Bar */}
          <div className="flex items-center gap-1.5 flex-wrap pt-1">
            <span className="text-xs text-slate-400 mr-1">Math Pad:</span>
            {mathSymbols.map((item) => (
              <button
                key={item.label}
                type="button"
                onClick={() => handleInsertSymbol(item.insert)}
                className="px-2.5 py-1 text-xs font-mono font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md transition-colors active:scale-95"
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Uploaded image chip if attached */}
          {uploadedImage && (
            <div className="flex items-center gap-3 p-2 bg-slate-50 border border-slate-200 rounded-xl">
              <img
                src={uploadedImage}
                alt="Attached problem"
                className="w-12 h-12 object-cover rounded-lg border border-slate-300"
              />
              <div className="flex-1 text-xs">
                <span className="font-semibold text-slate-800">Attached image attached to text prompt</span>
                <p className="text-slate-500">Gemini will analyze both together</p>
              </div>
              <button
                type="button"
                onClick={() => setUploadedImage(null)}
                className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Submit Row */}
          <div className="flex items-center justify-between pt-2">
            <span className="text-xs text-slate-500">
              {problemText.length > 0 ? `${problemText.length} characters` : 'Supports arithmetic, fractions, word stories, and pre-algebra'}
            </span>
            <button
              type="submit"
              disabled={isLoading || (!problemText.trim() && !uploadedImage)}
              className="flex items-center gap-2 px-6 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 rounded-xl shadow-xs transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isLoading ? 'Solving with AI Tutor...' : 'Solve Step-by-Step'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Mode 2: Interactive Scratchpad */}
      {inputMode === 'draw' && (
        <Scratchpad onSolveDrawing={handleSolveDrawing} isLoading={isLoading} />
      )}

      {/* Mode 3: Upload Photo */}
      {inputMode === 'photo' && (
        <div className="space-y-4">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />

          {!uploadedImage ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 hover:border-blue-400 bg-slate-50/60 hover:bg-blue-50/20 rounded-2xl p-8 text-center cursor-pointer transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-3">
                <ImageIcon className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-semibold text-slate-800">Upload a Photo of your Worksheet or Notebook</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                Snap a picture of handwritten homework or textbook problem. Our AI will read the math problem and explain it step by step!
              </p>
              <button
                type="button"
                className="mt-4 px-4 py-2 text-xs font-medium text-blue-700 bg-white border border-blue-200 rounded-lg shadow-xs hover:bg-blue-50"
              >
                Choose Image File
              </button>
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row items-center gap-4">
              <img
                src={uploadedImage}
                alt="Homework preview"
                className="max-h-48 max-w-xs object-contain rounded-lg border border-slate-300 bg-white"
              />
              <div className="space-y-3 flex-1">
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">Homework Photo Ready</h4>
                  <p className="text-xs text-slate-500">
                    You can add extra notes or questions below, or click solve directly.
                  </p>
                </div>
                <input
                  type="text"
                  value={problemText}
                  onChange={(e) => setProblemText(e.target.value)}
                  placeholder="Optional question or hint about this photo..."
                  className="w-full text-xs p-2 border border-slate-300 rounded-lg bg-white"
                />
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleSubmit()}
                    disabled={isLoading}
                    className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>{isLoading ? 'Reading & Solving...' : 'Solve This Photo'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setUploadedImage(null)}
                    className="px-3 py-2 text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded-lg"
                  >
                    Remove Photo
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
