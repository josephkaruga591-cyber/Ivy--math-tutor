import React, { useState } from 'react';
import {
  DragDropBlocksView,
  DragDropDivisionView,
  GeometricShapesView,
  InteractiveFractionBarsView,
  InteractiveNumberLineView,
  CoordinateGraphView,
} from './visuals/VisualManipulatives';
import {
  Sparkles,
  Layers,
  ArrowRight,
  Shapes,
  Divide,
  MoveHorizontal,
  PieChart,
  TrendingUp,
} from 'lucide-react';

interface InteractiveManipulativeLabProps {
  onSolveInSolver: (problemText: string) => void;
}

type ManipulativeTab = 'blocks' | 'division' | 'geometry' | 'fractions' | 'numberline' | 'coordinate';

export const InteractiveManipulativeLab: React.FC<InteractiveManipulativeLabProps> = ({
  onSolveInSolver,
}) => {
  const [activeTab, setActiveTab] = useState<ManipulativeTab>('blocks');

  // Presets for quick exploration
  const [blockPreset, setBlockPreset] = useState<{ a: number; b: number; target: number }>({
    a: 8,
    b: 6,
    target: 14,
  });

  const [divisionPreset, setDivisionPreset] = useState<{ total: number; groups: number }>({
    total: 15,
    groups: 3,
  });

  return (
    <div className="bg-white border border-slate-200/90 rounded-2xl p-6 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 font-display">
              Interactive Math Manipulatives Lab
            </h2>
            <p className="text-xs text-slate-500">
              Hands-on digital tools: drag, drop, slice, and measure to solve problems directly
            </p>
          </div>
        </div>

        <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-3 py-1 rounded-full self-start sm:self-auto">
          Active Sandbox
        </span>
      </div>

      {/* Manipulative Tool Tabs (Segmented Buttons) */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100/90 rounded-xl overflow-x-auto">
        <button
          onClick={() => setActiveTab('blocks')}
          className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
            activeTab === 'blocks'
              ? 'bg-white text-blue-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-blue-600" />
          <span>Drag & Drop Blocks (+)</span>
        </button>

        <button
          onClick={() => setActiveTab('division')}
          className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
            activeTab === 'division'
              ? 'bg-white text-blue-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Divide className="w-3.5 h-3.5 text-amber-600" />
          <span>Fair Sharing Plates (÷)</span>
        </button>

        <button
          onClick={() => setActiveTab('geometry')}
          className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
            activeTab === 'geometry'
              ? 'bg-white text-blue-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Shapes className="w-3.5 h-3.5 text-emerald-600" />
          <span>Shapes & Unit Grid (Area)</span>
        </button>

        <button
          onClick={() => setActiveTab('fractions')}
          className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
            activeTab === 'fractions'
              ? 'bg-white text-blue-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <PieChart className="w-3.5 h-3.5 text-indigo-600" />
          <span>Fraction Slices & Bars</span>
        </button>

        <button
          onClick={() => setActiveTab('numberline')}
          className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
            activeTab === 'numberline'
              ? 'bg-white text-blue-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <MoveHorizontal className="w-3.5 h-3.5 text-teal-600" />
          <span>Number Line Jumper</span>
        </button>

        <button
          onClick={() => setActiveTab('coordinate')}
          className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
            activeTab === 'coordinate'
              ? 'bg-white text-blue-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5 text-rose-600" />
          <span>Linear Graph (Grade 9)</span>
        </button>
      </div>

      {/* Tab 1: Drag & Drop Addition & Counting Blocks */}
      {activeTab === 'blocks' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-blue-50/60 rounded-xl border border-blue-100 text-xs">
            <span className="font-semibold text-blue-950">Quick Challenge Presets:</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setBlockPreset({ a: 7, b: 5, target: 12 })}
                className="px-2.5 py-1 bg-white border border-blue-200 text-blue-900 rounded-md font-semibold hover:bg-blue-50"
              >
                7 + 5 = 12
              </button>
              <button
                onClick={() => setBlockPreset({ a: 9, b: 6, target: 15 })}
                className="px-2.5 py-1 bg-white border border-blue-200 text-blue-900 rounded-md font-semibold hover:bg-blue-50"
              >
                9 + 6 = 15
              </button>
              <button
                onClick={() => setBlockPreset({ a: 12, b: 8, target: 20 })}
                className="px-2.5 py-1 bg-white border border-blue-200 text-blue-900 rounded-md font-semibold hover:bg-blue-50"
              >
                12 + 8 = 20
              </button>
            </div>
            <button
              onClick={() => onSolveInSolver(`What is ${blockPreset.a} + ${blockPreset.b}? Explain with regrouping steps.`)}
              className="flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 underline"
            >
              <span>Solve in AI Tutor</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <DragDropBlocksView
            key={`${blockPreset.a}-${blockPreset.b}`}
            initialA={blockPreset.a}
            initialB={blockPreset.b}
            targetSum={blockPreset.target}
            itemType="blocks"
          />
        </div>
      )}

      {/* Tab 2: Fair Sharing Division Mat */}
      {activeTab === 'division' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-amber-50/60 rounded-xl border border-amber-100 text-xs">
            <span className="font-semibold text-amber-950">Division Story Presets:</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setDivisionPreset({ total: 12, groups: 3 })}
                className="px-2.5 py-1 bg-white border border-amber-200 text-amber-900 rounded-md font-semibold hover:bg-amber-50"
              >
                12 cookies ÷ 3 plates
              </button>
              <button
                onClick={() => setDivisionPreset({ total: 16, groups: 4 })}
                className="px-2.5 py-1 bg-white border border-amber-200 text-amber-900 rounded-md font-semibold hover:bg-amber-50"
              >
                16 stickers ÷ 4 friends
              </button>
              <button
                onClick={() => setDivisionPreset({ total: 17, groups: 5 })}
                className="px-2.5 py-1 bg-white border border-amber-200 text-amber-900 rounded-md font-semibold hover:bg-amber-50"
              >
                17 apples ÷ 5 bags (Remainder!)
              </button>
            </div>
            <button
              onClick={() =>
                onSolveInSolver(
                  `There are ${divisionPreset.total} items shared equally among ${divisionPreset.groups} people. How many does each person get, and what is the remainder?`
                )
              }
              className="flex items-center gap-1 text-xs font-semibold text-amber-800 hover:text-amber-950 underline"
            >
              <span>Solve in AI Tutor</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <DragDropDivisionView
            key={`${divisionPreset.total}-${divisionPreset.groups}`}
            totalItems={divisionPreset.total}
            groupCount={divisionPreset.groups}
            itemLabel="items"
          />
        </div>
      )}

      {/* Tab 3: Geometric Shapes & Unit Grid */}
      {activeTab === 'geometry' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-emerald-50/60 rounded-xl border border-emerald-100 text-xs">
            <span className="font-semibold text-emerald-950">
              Interactive 2D Geometry: Drag sliders to resize shapes and count 1x1 unit squares!
            </span>
            <button
              onClick={() =>
                onSolveInSolver(
                  'A rectangular playground is 7 meters long and 5 meters wide. Calculate its area and perimeter step by step.'
                )
              }
              className="flex items-center gap-1 text-xs font-semibold text-emerald-800 hover:text-emerald-950 underline"
            >
              <span>Solve Playground Problem</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <GeometricShapesView
            initialShape="rectangle"
            initialWidth={6}
            initialHeight={4}
            unit="m"
            defaultShowGrid={true}
          />
        </div>
      )}

      {/* Tab 4: Interactive Fraction Slices */}
      {activeTab === 'fractions' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-indigo-50/60 rounded-xl border border-indigo-100 text-xs">
            <span className="font-semibold text-indigo-950">
              Fraction Strips: Tap slices to shade/unshade or click +/- to split into more equal parts!
            </span>
            <button
              onClick={() =>
                onSolveInSolver(
                  'Compare 3/4 and 2/3. Which fraction is larger, and what is their common denominator?'
                )
              }
              className="flex items-center gap-1 text-xs font-semibold text-indigo-800 hover:text-indigo-950 underline"
            >
              <span>Solve in AI Tutor</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <InteractiveFractionBarsView
            initialFractions={[
              { numerator: 3, denominator: 4, label: 'First Fraction (3/4)' },
              { numerator: 6, denominator: 8, label: 'Equivalent Fraction (6/8)' },
              { numerator: 1, denominator: 2, label: 'Half Fraction (1/2)' },
            ]}
          />
        </div>
      )}

      {/* Tab 5: Number Line Jumper */}
      {activeTab === 'numberline' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-teal-50/60 rounded-xl border border-teal-100 text-xs">
            <span className="font-semibold text-teal-950">
              Number Line Jumper: Hop the frog marker forward or backward to count intervals!
            </span>
            <button
              onClick={() =>
                onSolveInSolver(
                  'Start at 4 on a number line and make a jump of +9. What number do you land on?'
                )
              }
              className="flex items-center gap-1 text-xs font-semibold text-teal-800 hover:text-teal-950 underline"
            >
              <span>Solve in AI Tutor</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <InteractiveNumberLineView
            start={0}
            end={30}
            initialMarker={12}
            jumps={[
              { from: 0, to: 8, label: '+8' },
              { from: 8, to: 15, label: '+7' },
            ]}
          />
        </div>
      )}

      {/* Tab 6: Grade 9 Linear Graph on Coordinate Plane */}
      {activeTab === 'coordinate' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-rose-50/60 rounded-xl border border-rose-100 text-xs">
            <span className="font-semibold text-rose-950">
              Grade 9 Coordinate Plane: Explore slope-intercept form (y = mx + b) and see the line update in real time!
            </span>
            <button
              onClick={() =>
                onSolveInSolver(
                  'Graph the linear equation y = 2x - 3. Find the slope, y-intercept, x-intercept, and two points on the line.'
                )
              }
              className="flex items-center gap-1 text-xs font-semibold text-rose-800 hover:text-rose-950 underline"
            >
              <span>Solve in AI Tutor</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <CoordinateGraphView
            initialSlope={2}
            initialIntercept={-1}
          />
        </div>
      )}
    </div>
  );
};
