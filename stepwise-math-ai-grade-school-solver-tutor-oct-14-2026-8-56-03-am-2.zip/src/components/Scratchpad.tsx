import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Eraser, RotateCcw, PenTool, Sparkles, Grid3X3, AlignJustify, Square } from 'lucide-react';

interface ScratchpadProps {
  onSolveDrawing: (imageBase64: string) => void;
  isLoading: boolean;
}

type ToolMode = 'pen' | 'eraser';
type GridType = 'grid' | 'ruled' | 'blank';

export const Scratchpad: React.FC<ScratchpadProps> = ({ onSolveDrawing, isLoading }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [tool, setTool] = useState<ToolMode>('pen');
  const [color, setColor] = useState<string>('#1e293b');
  const [lineWidth, setLineWidth] = useState<number>(3);
  const [gridType, setGridType] = useState<GridType>('grid');
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [history, setHistory] = useState<ImageData[]>([]);

  // Setup canvas resolution and default background
  const initCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Fill white
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Save initial state to history
    setHistory([ctx.getImageData(0, 0, canvas.width, canvas.height)]);
  }, []);

  useEffect(() => {
    initCanvas();
  }, [initCanvas]);

  // Coordinate helper
  const getPos = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    if ('touches' in e) {
      const touch = e.touches[0];
      return {
        x: (touch.clientX - rect.left) * scaleX,
        y: (touch.clientY - rect.top) * scaleY,
      };
    }
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    const pos = getPos(e);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const pos = getPos(e);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (tool === 'eraser') {
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = lineWidth * 5;
    } else {
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;
    }

    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.closePath();

    // Save snapshot to history
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setHistory((prev) => [...prev.slice(-15), imgData]);
  };

  const handleUndo = () => {
    if (history.length <= 1) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const newHistory = history.slice(0, -1);
    const previousState = newHistory[newHistory.length - 1];
    ctx.putImageData(previousState, 0, 0);
    setHistory(newHistory);
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    setHistory([ctx.getImageData(0, 0, canvas.width, canvas.height)]);
  };

  const handleSolve = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    onSolveDrawing(dataUrl);
  };

  const colors = [
    { label: 'Slate', value: '#1e293b' },
    { label: 'Blue', value: '#2563eb' },
    { label: 'Emerald', value: '#059669' },
    { label: 'Amber', value: '#d97706' },
    { label: 'Purple', value: '#7c3aed' },
  ];

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
      {/* Top Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-50 border-b border-slate-200 text-xs">
        {/* Pen & Eraser */}
        <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200">
          <button
            onClick={() => setTool('pen')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
              tool === 'pen' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <PenTool className="w-3.5 h-3.5" />
            <span>Pen</span>
          </button>
          <button
            onClick={() => setTool('eraser')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
              tool === 'eraser' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Eraser className="w-3.5 h-3.5" />
            <span>Eraser</span>
          </button>
        </div>

        {/* Color Palette */}
        {tool === 'pen' && (
          <div className="flex items-center gap-1.5">
            {colors.map((c) => (
              <button
                key={c.value}
                onClick={() => setColor(c.value)}
                className={`w-6 h-6 rounded-full transition-transform ${
                  color === c.value ? 'scale-110 ring-2 ring-slate-400 ring-offset-1' : 'opacity-80 hover:opacity-100'
                }`}
                style={{ backgroundColor: c.value }}
                title={c.label}
              />
            ))}
          </div>
        )}

        {/* Stroke thickness */}
        <div className="flex items-center gap-2">
          <span className="text-slate-500">Size:</span>
          {[2, 4, 7].map((s) => (
            <button
              key={s}
              onClick={() => setLineWidth(s)}
              className={`w-6 h-6 rounded-md flex items-center justify-center font-mono text-xs ${
                lineWidth === s ? 'bg-slate-200 text-slate-900 font-bold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {s === 2 ? 'S' : s === 4 ? 'M' : 'L'}
            </button>
          ))}
        </div>

        {/* Paper Grid Switcher */}
        <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200">
          <button
            onClick={() => setGridType('grid')}
            className={`p-1.5 rounded ${gridType === 'grid' ? 'bg-slate-200 text-slate-900' : 'text-slate-500 hover:text-slate-800'}`}
            title="Math Grid Paper"
          >
            <Grid3X3 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setGridType('ruled')}
            className={`p-1.5 rounded ${gridType === 'ruled' ? 'bg-slate-200 text-slate-900' : 'text-slate-500 hover:text-slate-800'}`}
            title="Ruled Notebook Lines"
          >
            <AlignJustify className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setGridType('blank')}
            className={`p-1.5 rounded ${gridType === 'blank' ? 'bg-slate-200 text-slate-900' : 'text-slate-500 hover:text-slate-800'}`}
            title="Blank Whiteboard"
          >
            <Square className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Undo & Clear */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleUndo}
            disabled={history.length <= 1}
            className="p-1.5 rounded text-slate-600 hover:text-slate-900 hover:bg-slate-200 disabled:opacity-30 disabled:pointer-events-none"
            title="Undo stroke"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={handleClear}
            className="px-2.5 py-1 text-slate-600 hover:text-rose-700 hover:bg-rose-50 rounded transition-colors"
          >
            Clear
          </button>
        </div>
      </div>

      {/* Canvas Area with Background styling */}
      <div
        className={`relative w-full overflow-hidden select-none touch-none ${
          gridType === 'grid'
            ? 'bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:24px_24px]'
            : gridType === 'ruled'
            ? 'bg-[linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:100%_28px]'
            : 'bg-white'
        }`}
      >
        <canvas
          ref={canvasRef}
          width={900}
          height={380}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          className="w-full h-[280px] sm:h-[340px] cursor-crosshair bg-transparent"
        />

        {/* Subtle Watermark Hint */}
        <div className="absolute bottom-3 left-4 text-xs text-slate-400 pointer-events-none">
          Draw numbers, fractions, geometry shapes, or long division here with your mouse or finger
        </div>
      </div>

      {/* Footer Solve Action */}
      <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
        <span className="text-xs text-slate-500">
          Ready to solve your handwriting or sketch?
        </span>
        <button
          onClick={handleSolve}
          disabled={isLoading}
          className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 rounded-lg shadow-xs transition-colors"
        >
          <Sparkles className="w-4 h-4" />
          <span>{isLoading ? 'Reading Drawing & Solving...' : 'Solve My Scratchpad Work'}</span>
        </button>
      </div>
    </div>
  );
};
