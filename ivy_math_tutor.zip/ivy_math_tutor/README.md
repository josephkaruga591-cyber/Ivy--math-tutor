# Ivy AI Math Tutor

A responsive starter web app for a step-by-step maths tutor. It is designed to work well on Android screens and can be deployed as a web app.

## Included

- Mobile-friendly tutor interface
- Grade selector (Grades 7–10 and other level)
- Suggested prompts for algebra, geometry, percentages, and practice
- Server-side AI endpoint using Google GenAI
- API key stays on the server (not in browser JavaScript)
- Helpful error messages when AI is not configured or the server is offline

## What you need

- A computer or a hosting service that can run Node.js 18+
- A Google AI Studio API key
- Internet access for AI responses

The app UI is built, but AI responses will not work until you configure the API key and run the server. The key may be subject to Google AI Studio's usage limits and billing terms.

## Run it on a computer

1. Extract the ZIP.
2. Install Node.js 18 or newer from https://nodejs.org/.
3. Open a terminal in the extracted `ivy_math_tutor` folder.
4. Run `npm install`.
5. Copy `.env.example` to a new file named `.env`.
6. Open `.env` and replace `replace_with_your_api_key` with your Google AI Studio API key.
7. Run `npm start`.
8. Open `http://localhost:3000` in your browser.

Keep `.env` private. Do not send it to anyone or publish it online.

## Can I run it directly on my Android phone?

The project files can be stored on your phone, but the Node.js server and AI API connection need to run in a suitable environment or be deployed to a hosting service. For normal use on your phone, deploy the app and open its web address in Chrome. You can then use Chrome's **Add to Home screen** option if your deployment supports it.

## Important before public launch

- Add rate limiting, abuse protection, and monitoring to the API endpoint.
- Review the AI provider's terms, data handling, and costs.
- Add a privacy policy before collecting personal information.
- If charging learners, add and test a payment provider securely; payments are not implemented in this starter.
- Test maths answers carefully. AI can make mistakes.
- Configure HTTPS when deployed publicly.

## Project structure

```text
ivy_math_tutor/
  server.js
  package.json
  .env.example
  .gitignore
  README.md
  public/
    index.html
    styles.css
    app.js
```
