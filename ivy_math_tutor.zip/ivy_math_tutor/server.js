import "dotenv/config";
import express from "express";
import { GoogleGenAI } from "@google/genai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const port = Number(process.env.PORT || 3000);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(process.env.GEMINI_API_KEY) });
});

app.post("/api/tutor", async (req, res) => {
  const question = String(req.body?.question || "").trim();
  const grade = String(req.body?.grade || "Grade 9").trim().slice(0, 40);

  if (!question) return res.status(400).json({ error: "Please enter a maths question." });
  if (question.length > 4000) return res.status(413).json({ error: "Please keep the question under 4,000 characters." });

  if (!process.env.GEMINI_API_KEY) {
    return res.status(503).json({
      error: "AI is not connected yet. Add your Google AI Studio API key to the server's .env file, then restart the app."
    });
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const prompt = `You are Ivy, a patient and encouraging mathematics tutor for learners in Kenya.
The learner selected ${grade}. Use clear language suitable for that level.
Answer the learner's question accurately. For calculations, show numbered working steps, explain why each step is done, and clearly mark the final answer.
If the question is ambiguous, state your assumption or ask one concise clarifying question.
Do not just give the answer: teach the method. Use Kenyan school mathematics terminology where appropriate.
Question: ${question}`;

    const result = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt
    });

    const answer = result.text?.trim();
    if (!answer) throw new Error("The AI returned an empty answer.");
    res.json({ answer });
  } catch (error) {
    console.error("Tutor API error:", error?.message || error);
    res.status(502).json({ error: "I couldn't get an AI answer just now. Check the server connection and API configuration, then try again." });
  }
});

app.listen(port, () => {
  console.log(`Ivy Math Tutor is running at http://localhost:${port}`);
});
