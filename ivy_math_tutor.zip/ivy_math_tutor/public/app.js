const form = document.querySelector("#questionForm");
const input = document.querySelector("#questionInput");
const conversation = document.querySelector("#conversation");
const welcome = document.querySelector("#welcome");
const gradeSelect = document.querySelector("#gradeSelect");
const sendBtn = document.querySelector("#sendBtn");
const connectionLabel = document.querySelector("#connectionLabel");
const toast = document.querySelector("#toast");
const sidebar = document.querySelector(".sidebar");

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 3500);
}

function addMessage(role, text, isTyping = false) {
  conversation.classList.add("has-messages");
  const message = document.createElement("article");
  message.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "You" : "∑";
  const content = document.createElement("div");
  content.className = "message-content";
  const label = document.createElement("div");
  label.className = "message-label";
  label.textContent = role === "user" ? "Your question" : "Ivy · Math tutor";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (isTyping) {
    bubble.innerHTML = '<span class="typing" aria-label="Ivy is thinking"><i></i><i></i><i></i></span>';
    message.dataset.typing = "true";
  } else {
    // Use textContent so model responses are shown as text, not executable HTML.
    bubble.textContent = text;
  }
  content.append(label, bubble);
  message.append(avatar, content);
  conversation.append(message);
  message.scrollIntoView({ behavior: "smooth", block: "nearest" });
  return message;
}

async function ask(question) {
  const cleanQuestion = question.trim();
  if (!cleanQuestion) return;
  welcome.hidden = true;
  addMessage("user", cleanQuestion);
  input.value = "";
  resizeInput();
  sendBtn.disabled = true;
  sendBtn.querySelector("span:first-child").textContent = "Thinking";
  const typingMessage = addMessage("assistant", "", true);

  try {
    const response = await fetch("/api/tutor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question: cleanQuestion, grade: gradeSelect.value })
    });
    const data = await response.json().catch(() => ({}));
    typingMessage.remove();
    if (!response.ok) {
      addMessage("assistant", data.error || "I couldn't answer that just now. Please try again.");
      if (response.status === 503) connectionLabel.textContent = "AI setup needed";
    } else {
      addMessage("assistant", data.answer || "I didn't receive an answer. Please try again.");
      connectionLabel.textContent = "AI connected";
    }
  } catch (_error) {
    typingMessage.remove();
    addMessage("assistant", "I can't reach the tutor server. Make sure the app server is running and your phone has an internet connection.");
    connectionLabel.textContent = "Server offline";
  } finally {
    sendBtn.disabled = false;
    sendBtn.querySelector("span:first-child").textContent = "Ask Ivy";
    input.focus();
  }
}

function resizeInput() {
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
}

form.addEventListener("submit", event => {
  event.preventDefault();
  ask(input.value);
});

input.addEventListener("input", resizeInput);
input.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => {
    const prompt = button.dataset.prompt;
    sidebar.classList.remove("open");
    ask(prompt);
  });
});

document.querySelector("#newChatBtn").addEventListener("click", () => {
  conversation.replaceChildren();
  conversation.classList.remove("has-messages");
  welcome.hidden = false;
  input.value = "";
  resizeInput();
  sidebar.classList.remove("open");
  input.focus();
});

document.querySelector("#menuBtn").addEventListener("click", () => sidebar.classList.toggle("open"));

document.addEventListener("click", event => {
  if (window.innerWidth <= 800 && sidebar.classList.contains("open") &&
      !sidebar.contains(event.target) && !event.target.closest("#menuBtn")) {
    sidebar.classList.remove("open");
  }
});

fetch("/api/health")
  .then(response => response.json())
  .then(data => {
    connectionLabel.textContent = data.aiConfigured ? "AI ready" : "Setup needed";
  })
  .catch(() => {
    connectionLabel.textContent = "Tutor ready";
  });
